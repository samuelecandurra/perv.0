"use client"

import { useEffect, useContext } from "react"
import { NavigationContext } from "@/App"
import SignUpModal from "@/components/ui/SignUpModal"

const Auth = () => {
  const { navigationState, navigate } = useContext(NavigationContext)
  const { returnTo, action } = navigationState || { returnTo: "/dashboard", action: null }

  // Check if user is already authenticated
  useEffect(() => {
    if (localStorage.getItem("userAuthenticated") === "true") {
      navigate(returnTo || "/dashboard")
    }
  }, [navigate, returnTo])

  return (
    <div className="min-h-screen bg-[#FFF7EF] py-12 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
      <div className="max-w-6xl w-full bg-white rounded-2xl shadow-sm overflow-hidden">
        <div className="flex flex-col md:flex-row">
          <div className="w-full md:w-1/2 p-8">
            <SignUpModal returnTo={returnTo} action={action} />
          </div>

          <div className="hidden md:block md:w-1/2 bg-orange-50 p-8">
            <div className="h-full flex flex-col justify-center items-center">
              <img
                src="/lovable-uploads/1a37ec04-9f95-4504-bd49-4e8a31547ccb.png"
                alt="Seribook illustration"
                className="max-w-xs mx-auto mb-8"
              />
              <h3 className="text-2xl font-bold text-center mb-4">Pubblica il tuo libro in pochi minuti</h3>
              <p className="text-center text-gray-600 max-w-xs">
                Crea un account per iniziare a creare il tuo libro con Seribook.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Auth

