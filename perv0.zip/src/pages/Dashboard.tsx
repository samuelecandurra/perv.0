"use client"

import { useState, useContext, useEffect } from "react"
import { NavigationContext } from "@/App"
import Link from "@/components/ui/Link"
import { Button } from "@/components/ui/button"
import { BookOpen, Plus, LogOut, Settings, BookText, Home, Edit, Lock, CheckCircle } from "lucide-react"
import { toast } from "sonner"
import { Badge } from "@/components/ui/badge"
import EditorLockedModal from "@/components/EditorLockedModal"

const Dashboard = () => {
  const { navigationState, navigate } = useContext(NavigationContext)
  const [userName, setUserName] = useState("Utente")
  const [selectedProject, setSelectedProject] = useState<{ id: number; title: string } | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  useEffect(() => {
    // Get username from navigation state or localStorage
    if (navigationState?.userName) {
      setUserName(navigationState.userName)
    } else {
      const storedName = localStorage.getItem("userName")
      if (storedName) {
        setUserName(storedName)
      }
    }
  }, [navigationState])

  const handleLogout = () => {
    localStorage.removeItem("userAuthenticated")
    localStorage.removeItem("userName")
    toast.success("Logout effettuato con successo")
    navigate("/")
  }

  const isProjectUnlocked = (projectId: number) => {
    return projectId === 1
  }

  const handleEditClick = (project: { id: number; title: string }) => {
    if (isProjectUnlocked(project.id)) {
      navigate("/book-editor", { projectId: project.id, projectTitle: project.title })
    } else {
      setSelectedProject(project)
      setIsModalOpen(true)
    }
  }

  const projects = [
    {
      id: 1,
      title: "Il mio primo libro",
      description: "Una guida completa al self-publishing",
      progress: 70,
      lastEdited: "2 giorni fa",
      wordCount: 8500,
      totalWords: 10000,
    },
    {
      id: 2,
      title: "Ricette italiane",
      description: "Raccolta delle migliori ricette della tradizione",
      progress: 30,
      lastEdited: "5 giorni fa",
      wordCount: 2500,
      totalWords: 5000,
    },
  ]

  // Calcola il totale delle parole utilizzate e disponibili
  const totalUsedWords = projects.reduce((sum, project) => sum + project.wordCount, 0)
  const totalAvailableWords = projects.reduce((sum, project) => sum + project.totalWords, 0)
  const remainingWords = totalAvailableWords - totalUsedWords
  const remainingPercentage = Math.round((remainingWords / totalAvailableWords) * 100)

  // Determina il colore in base alle parole rimanenti
  const getWordCountColor = () => {
    const percentage = (remainingWords / totalAvailableWords) * 100
    if (percentage > 30) return "text-green-500"
    if (percentage > 10) return "text-amber-500"
    return "text-red-500"
  }

  return (
    <div className="min-h-screen bg-[#FFF7EF] flex">
      <div className="w-64 bg-white border-r border-gray-200 min-h-screen p-4 hidden md:block">
        <div className="flex flex-col h-full">
          <div className="mb-8">
            <Link to="/" className="flex items-center mb-8">
              <img
                src="/lovable-uploads/ac709032-b968-4d6c-b151-99aa574cad77.png"
                alt="Seribook Logo"
                className="h-8"
              />
            </Link>

            <h2 className="text-xl font-semibold mb-1">Benvenuto, {userName}</h2>
            <p className="text-sm text-gray-500">Il tuo spazio creativo</p>
          </div>

          <nav className="space-y-1 flex-1">
            <Link
              to="/dashboard"
              className="flex items-center px-3 py-2 text-sm font-medium rounded-md bg-orange-soft text-orange"
            >
              <BookText className="mr-3 h-5 w-5" />I miei progetti
            </Link>

            <Link
              to="/create-book"
              className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-orange transition-colors"
            >
              <Plus className="mr-3 h-5 w-5" />
              Nuovo progetto
            </Link>

            <Link
              to="/"
              className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-orange transition-colors"
            >
              <Home className="mr-3 h-5 w-5" />
              Home
            </Link>

            <a
              href="#"
              className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-orange transition-colors"
            >
              <Settings className="mr-3 h-5 w-5" />
              Impostazioni
            </a>

            {/* Word count indicator */}
            <div className="mt-6 px-3 py-4">
              <p className="text-sm font-medium text-gray-600 mb-2">Parole rimanenti</p>
              <div className="flex items-center justify-center mb-2">
                <div
                  className={`relative w-24 h-24 flex items-center justify-center rounded-full border-4 ${getWordCountColor().replace("text-", "border-")}`}
                >
                  <span className={`text-lg font-bold ${getWordCountColor()}`}>{Math.round(remainingPercentage)}%</span>
                </div>
              </div>
              <div className="text-center text-sm">
                <span className={`font-medium ${getWordCountColor()}`}>{remainingWords.toLocaleString("it-IT")}</span>
                <span className="text-gray-500"> / {totalAvailableWords.toLocaleString("it-IT")}</span>
              </div>
            </div>
          </nav>

          <div className="mt-auto">
            <button
              onClick={handleLogout}
              className="flex items-center px-3 py-2 w-full text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-orange transition-colors"
            >
              <LogOut className="mr-3 h-5 w-5" />
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="md:hidden fixed top-0 left-0 right-0 bg-white border-b border-gray-200 z-10">
        <div className="flex items-center justify-between p-4">
          <Link to="/" className="flex items-center">
            <img src="/lovable-uploads/ac709032-b968-4d6c-b151-99aa574cad77.png" alt="Seribook Logo" className="h-8" />
          </Link>

          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" onClick={handleLogout} className="text-gray-500 hover:text-orange">
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <main className="py-8 px-4 md:px-8 max-w-4xl mx-auto mt-16 md:mt-0">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-2xl font-bold">I miei progetti</h1>
            <Link to="/create-book">
              <Button className="bg-orange hover:bg-orange-light text-white rounded-full">
                <Plus className="mr-2 h-4 w-4" />
                Nuovo progetto
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {projects.map((project) => (
              <div
                key={project.id}
                className="bg-white rounded-lg border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow card-hover"
              >
                <div className="p-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                      <p className="text-gray-600 mb-3">{project.description}</p>
                    </div>
                    <BookOpen className="text-orange h-6 w-6" />
                  </div>

                  <div className="mt-4">
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-500">Progresso</span>
                      <span className="font-medium">{project.progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-orange h-2 rounded-full" style={{ width: `${project.progress}%` }} />
                    </div>

                    <div className="mt-3">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-500">Parole utilizzate</span>
                        <span className="font-medium">
                          {project.wordCount.toLocaleString("it-IT")} / {project.totalWords.toLocaleString("it-IT")}
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                        <div
                          className={`h-2 rounded-full ${
                            (project.totalWords - project.wordCount) > 1000
                              ? "bg-green-500"
                              : project.totalWords - project.wordCount > 300
                                ? "bg-amber-500"
                                : "bg-red-500"
                          }`}
                          style={{ width: `${(project.wordCount / project.totalWords) * 100}%` }}
                        />
                      </div>
                    </div>

                    <div className="mt-2">
                      {isProjectUnlocked(project.id) ? (
                        <Badge
                          variant="secondary"
                          className="flex items-center gap-1 w-fit bg-green-50 text-green-600 border-green-200"
                        >
                          <CheckCircle className="h-3 w-3 text-green-500" />
                          <span>Editor disponibile</span>
                        </Badge>
                      ) : (
                        <Badge
                          variant="outline"
                          className="flex items-center gap-1 w-fit text-gray-500 border-gray-300"
                        >
                          <Lock className="h-3 w-3" />
                          <span>Sblocca per modificare</span>
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="mt-6 flex items-center justify-between">
                    <span className="text-xs text-gray-500">Modificato {project.lastEdited}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-orange hover:text-orange-light hover:bg-orange-soft/50"
                      onClick={() => handleEditClick(project)}
                    >
                      <Edit className="mr-1 h-4 w-4" />
                      Modifica
                    </Button>
                  </div>
                </div>
              </div>
            ))}

            <Link
              to="/create-book"
              className="border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center p-6 bg-white hover:border-orange/60 hover:bg-orange-soft/20 transition-colors cursor-pointer min-h-[200px]"
            >
              <div className="text-center">
                <div className="flex justify-center">
                  <Plus className="h-10 w-10 text-gray-400 group-hover:text-orange" />
                </div>
                <h3 className="mt-2 text-sm font-medium text-gray-900">Nuovo progetto</h3>
                <p className="mt-1 text-xs text-gray-500">Crea un nuovo libro</p>
              </div>
            </Link>
          </div>
        </main>
      </div>

      {selectedProject && (
        <EditorLockedModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          projectTitle={selectedProject.title}
          projectId={selectedProject.id}
        />
      )}
    </div>
  )
}

export default Dashboard

