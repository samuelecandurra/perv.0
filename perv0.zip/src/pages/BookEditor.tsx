"use client"

import { useState, useEffect, useContext } from "react"
import { NavigationContext } from "@/App"
import { toast } from "sonner"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Save } from "lucide-react"

// Import new components
import EditorHeader from "@/components/editor/EditorHeader"
import ChaptersSidebar from "@/components/editor/ChaptersSidebar"
import TextEditor from "@/components/editor/TextEditor"
import SuggestionsSidebar from "@/components/editor/SuggestionsSidebar"

const BookEditor = () => {
  const { params, navigationState, navigate } = useContext(NavigationContext)
  const [bookData, setBookData] = useState(navigationState?.bookData || null)
  const [projectId, setProjectId] = useState(params.id || navigationState?.projectId || null)
  const [projectTitle, setProjectTitle] = useState(navigationState?.projectTitle || "Libro senza titolo")
  const [activeChapter, setActiveChapter] = useState(0)
  const [chapters, setChapters] = useState([])
  const [chapterContent, setChapterContent] = useState("")
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768)
  const [activeTab, setActiveTab] = useState("editor")
  const [wordCount, setWordCount] = useState(0)
  const [remainingWords, setRemainingWords] = useState(10000)

  useEffect(() => {
    if (projectId) {
      console.log(`Loading project with ID: ${projectId}`)

      const generatedChapters = [
        { id: 0, title: "Introduzione", status: "completed", content: "Introduzione al libro..." },
        {
          id: 1,
          title: `Capitolo 1 - Progetto ${projectId}`,
          status: "editing",
          content: `Contenuto del capitolo 1 per progetto ${projectId}...`,
        },
        { id: 2, title: "Capitolo 2", status: "pending", content: "Contenuto del capitolo 2..." },
      ]

      setChapters(generatedChapters)
      setChapterContent(generatedChapters[0].content)

      toast.success("Progetto caricato", {
        description: `Hai aperto il progetto "${projectTitle}"`,
      })
    } else if (bookData) {
      if (bookData.bookStructure && bookData.bookStructure.length > 0) {
        const generatedChapters = bookData.bookStructure.map((title, index) => ({
          id: index,
          title,
          status: index === 0 ? "completed" : index === 1 ? "editing" : "pending",
          content: index === 0 ? bookData.generatedPreview || "Contenuto del capitolo..." : "Contenuto del capitolo...",
        }))
        setChapters(generatedChapters)
        setChapterContent(generatedChapters[0].content)

        if (bookData.wordCount) {
          const limit = Number.parseInt(bookData.wordCount, 10)
          setRemainingWords(isNaN(limit) ? 10000 : limit)
        }
      } else {
        const defaultChapters = [
          {
            id: 0,
            title: "Introduzione",
            status: "completed",
            content: bookData.generatedPreview || "Introduzione del libro...",
          },
          { id: 1, title: "Capitolo 1", status: "editing", content: "Contenuto del capitolo 1..." },
          { id: 2, title: "Capitolo 2", status: "pending", content: "Contenuto del capitolo 2..." },
        ]
        setChapters(defaultChapters)
        setChapterContent(defaultChapters[0].content)
      }
    } else {
      navigate("/create-book")
      return
    }

    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768)
    }
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [bookData, navigate, projectId, projectTitle])

  useEffect(() => {
    const words = chapterContent.split(/\s+/).filter((word) => word.length > 0)
    setWordCount(words.length)

    const totalWords = chapters.reduce((total, chapter) => {
      const chapterWords = chapter.content.split(/\s+/).filter((word) => word.length > 0).length
      return total + chapterWords
    }, 0)

    if (bookData?.wordCount) {
      const limit = Number.parseInt(bookData.wordCount, 10)
      const remainingCount = isNaN(limit) ? 10000 - totalWords : limit - totalWords
      setRemainingWords(remainingCount < 0 ? 0 : remainingCount)
    } else {
      setRemainingWords(10000 - totalWords)
    }
  }, [chapterContent, chapters, bookData])

  const handleChapterClick = (index) => {
    setActiveChapter(index)
    setChapterContent(chapters[index].content)
  }

  const handleContentChange = (e) => {
    const newContent = e.target.value
    setChapterContent(newContent)

    const updatedChapters = [...chapters]
    updatedChapters[activeChapter].content = newContent
    setChapters(updatedChapters)
  }

  const handleTitleChange = (title) => {
    const updatedChapters = [...chapters]
    updatedChapters[activeChapter].title = title
    setChapters(updatedChapters)
  }

  const handleSave = () => {
    toast("Modifiche salvate", {
      description: `${chapters[activeChapter].title} aggiornato con successo`,
      action: {
        label: "Chiudi",
        onClick: () => {},
      },
    })
  }

  const handleResetToAIVersion = () => {
    toast("Testo ripristinato", {
      description: "Il testo è stato ripristinato alla versione originale AI",
    })
  }

  const applyAISuggestion = (suggestionType) => {
    toast("Suggerimento applicato", {
      description: `${suggestionType} applicato al testo`,
    })
  }

  const handlePreviewClick = () => {
    toast("Anteprima completa", {
      description: "Visualizzazione completa del libro",
    })
  }

  const handleExport = (format) => {
    toast.success(`Esportazione in ${format} avviata`, {
      description: "Il file sarà pronto a breve per il download",
    })

    setTimeout(() => {
      toast.success(`Esportazione in ${format} completata`, {
        description: "Il file è pronto per il download",
        action: {
          label: "Scarica",
          onClick: () => console.log(`Downloading ${format} file...`),
        },
      })
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Top Navigation */}
      <EditorHeader wordCount={wordCount} handleExport={handleExport} handleSave={handleSave} />

      {/* Mobile Tabs */}
      {isMobile && (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="chapters">Capitoli</TabsTrigger>
            <TabsTrigger value="editor">Editor</TabsTrigger>
            <TabsTrigger value="suggestions">Suggerimenti</TabsTrigger>
          </TabsList>
        </Tabs>
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar: Chapters */}
        {(!isMobile || activeTab === "chapters") && (
          <ChaptersSidebar
            chapters={chapters}
            activeChapter={activeChapter}
            remainingWords={remainingWords}
            bookWordCount={bookData?.wordCount}
            onChapterClick={handleChapterClick}
          />
        )}

        {/* Main Editor Area */}
        {(!isMobile || activeTab === "editor") && (
          <div className="flex-1 overflow-y-auto p-4 relative bg-gray-50">
            <TextEditor
              chapterTitle={chapters[activeChapter]?.title || ""}
              chapterContent={chapterContent}
              onTitleChange={handleTitleChange}
              onContentChange={handleContentChange}
              onResetToAIVersion={handleResetToAIVersion}
              onPreviewClick={handlePreviewClick}
            />

            {/* Mobile fixed save button */}
            {isMobile && (
              <div className="fixed bottom-6 right-6 z-50">
                <Button
                  onClick={handleSave}
                  size="sm"
                  className="shadow-md rounded-full h-12 w-12 p-0 bg-[#FF5500] hover:bg-[#FF5500]/90 text-white pulse-animation"
                >
                  <Save className="h-5 w-5" />
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Right Panel: AI Suggestions */}
        {(!isMobile || activeTab === "suggestions") && <SuggestionsSidebar onApplySuggestion={applyAISuggestion} />}
      </div>
    </div>
  )
}

export default BookEditor

