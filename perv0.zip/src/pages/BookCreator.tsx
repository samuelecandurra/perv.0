"use client"

import { useState, useEffect, useContext } from "react"
import { NavigationContext } from "@/App"
import Link from "@/components/ui/Link"
import BookDetailsStep from "@/components/wizard/BookDetailsStep"
import DescriptionBriefStep from "@/components/wizard/DescriptionBriefStep"
import BookPreviewStep from "@/components/wizard/BookPreviewStep"
import NarrativeVoiceStep from "@/components/wizard/NarrativeVoiceStep"
import StepIndicator from "@/components/wizard/StepIndicator"
import WizardLayout from "@/components/wizard/WizardLayout"
import { Button } from "@/components/ui/button"
import { BookOpen, Edit, ArrowLeft, Check } from "lucide-react"
import { toast } from "sonner"

const BookCreator = () => {
  const { navigationState, navigate } = useContext(NavigationContext)
  const [currentStep, setCurrentStep] = useState(0)
  const [bookData, setBookData] = useState({
    type: "",
    language: "",
    niche: "",
    title: "",
    subtitle: "",
    wordCount: "",
    tone: "",
    audience: "",
    description: "",
    generatedBrief: "",
    uniqueSellingPoint: "",
    graphicTemplate: "none",
    colorScheme: "blue",
    includeImages: "none",
    imageCount: 10,
    bookStructure: [],
    generatedPreview: "",
    format: "",
    trimWidth: "",
    trimHeight: "",
    narrativeVoice: "",
    contentDetails: {
      recipeCount: 0,
      quizCount: 0,
      exerciseCount: 0,
      chapterCount: 0,
    },
    chapterStructure: [] as { title: string; content: string }[],
    bonusContent: [] as { title: string; description: string }[],
    includeQuizzes: "no",
  })

  const totalSteps = 4

  // Check authentication on mount
  useEffect(() => {
    if (!isAuthenticated()) {
      navigate("/auth", { returnTo: "/create-book" })
      return
    }

    // If we have startAction from navigation state, automatically start the appropriate flow
    if (navigationState && navigationState.action) {
      if (navigationState.action === "new") {
        updateBookData({ type: "new" })
        setCurrentStep(1)
        window.scrollTo(0, 0)
      } else if (navigationState.action === "improve") {
        updateBookData({ type: "improve" })
        setCurrentStep(1)
        window.scrollTo(0, 0)
      }
    }
  }, [navigationState, navigate])

  const updateBookData = (data: Partial<typeof bookData>) => {
    setBookData((prev) => ({ ...prev, ...data }))
  }

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep((prev) => prev + 1)
      window.scrollTo(0, 0)
    } else {
      console.log("Book creation completed:", bookData)
      toast.success("Libro creato con successo!")
      navigate("/dashboard")
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1)
      window.scrollTo(0, 0)
    }
  }

  // Check if user is authenticated
  const isAuthenticated = () => {
    return localStorage.getItem("userAuthenticated") === "true"
  }

  const handleStartNewBook = () => {
    updateBookData({ type: "new" })
    setCurrentStep(1)
    window.scrollTo(0, 0)
  }

  const handleImproveExistingBook = () => {
    updateBookData({ type: "improve" })
    setCurrentStep(1)
    window.scrollTo(0, 0)
  }

  const handleBackToStart = () => {
    setCurrentStep(0)
    window.scrollTo(0, 0)
  }

  return (
    <WizardLayout>
      <div className="book-creator-container font-['Inter',_'SF_Pro_Text',_-apple-system,_BlinkMacSystemFont,_'Segoe_UI',_Roboto,_'Helvetica_Neue',_Arial,_sans-serif]">
        {currentStep > 0 && (
          <div className="mb-8">
            <StepIndicator currentStep={currentStep} totalSteps={totalSteps} />

            {currentStep === 1 && (
              <Button variant="ghost" className="mt-4 flex items-center text-gray-600" onClick={handleBackToStart}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Torna alla selezione iniziale
              </Button>
            )}
          </div>
        )}

        {currentStep === 0 && (
          <div className="text-center py-8">
            <h1 className="text-3xl md:text-4xl font-semibold mb-8">Cosa vuoi fare oggi?</h1>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto mb-12">
              <div className="bg-white border border-gray-200 rounded-lg p-8 flex flex-col items-center text-center hover:shadow-lg transition-shadow cursor-pointer">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <BookOpen className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Start Creating Your Ebook</h3>
                <p className="text-gray-600 mb-6">Create a new ebook from scratch with our guided wizard</p>
                <Button className="bg-[#FF5500] hover:bg-[#FF5500]/90 text-white" onClick={handleStartNewBook}>
                  Start Creating
                </Button>
              </div>

              <div className="bg-white border border-gray-200 rounded-lg p-8 flex flex-col items-center text-center hover:shadow-lg transition-shadow cursor-pointer">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                  <Edit className="h-8 w-8 text-gray-600" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Improve Your Existing Ebook</h3>
                <p className="text-gray-600 mb-6">Upload an existing ebook to enhance it with AI</p>
                <Button
                  variant="outline"
                  className="border-[#FF5500]/30 text-[#FF5500] hover:bg-[#FF5500]/10"
                  onClick={handleImproveExistingBook}
                >
                  Improve Existing
                </Button>
              </div>
            </div>

            <div className="mt-8 mb-6">
              <Link to="/">
                <Button variant="ghost" className="flex items-center text-gray-600">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Torna alla dashboard
                </Button>
              </Link>
            </div>

            <div className="mt-16 mb-12">
              <h2 className="text-2xl md:text-3xl font-semibold mb-3 text-left">
                Come Seribook trasforma il self-publishing
              </h2>
              <p className="text-left text-gray-600 mb-8 text-lg font-medium">
                Pronto per Amazon KDP, Kobo, Apple Books e tutte le piattaforme digitali. Senza nessun blocco.
              </p>

              <div className="space-y-6 text-left">
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                    <Check className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Creazione in 5 minuti</h3>
                    <p className="text-gray-600">
                      Inserisci la tua idea, specifica alcune preferenze e lascia che la nostra AI generi un libro
                      completo in pochi minuti.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                    <Check className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Qualità professionale</h3>
                    <p className="text-gray-600">
                      Contenuti ben strutturati, scritti con stile professionale e pronti per la pubblicazione
                      immediata.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                    <Check className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Completa personalizzazione</h3>
                    <p className="text-gray-600">
                      Modifica, aggiungi o riorganizza il contenuto generato con il nostro editor intuitivo.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                    <Check className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Protezione copyright e anti-plagio</h3>
                    <p className="text-gray-600">
                      Sistema avanzato che garantisce contenuti originali e protetti, evitando problemi di copyright e
                      plagio.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                    <Check className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Export multi-formato</h3>
                    <p className="text-gray-600">
                      Esporta in PDF, EPUB, MOBI e altri formati compatibili con tutte le piattaforme di pubblicazione.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {currentStep === 1 && <BookDetailsStep onUpdate={updateBookData} onNext={handleNext} bookData={bookData} />}

        {currentStep === 2 && (
          <NarrativeVoiceStep onUpdate={updateBookData} onNext={handleNext} onBack={handleBack} bookData={bookData} />
        )}

        {currentStep === 3 && (
          <DescriptionBriefStep onUpdate={updateBookData} onNext={handleNext} onBack={handleBack} bookData={bookData} />
        )}

        {currentStep === 4 && (
          <BookPreviewStep onUpdate={updateBookData} onNext={handleNext} onBack={handleBack} bookData={bookData} />
        )}
      </div>
    </WizardLayout>
  )
}

export default BookCreator

