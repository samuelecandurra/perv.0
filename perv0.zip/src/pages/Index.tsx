"use client"

import { useEffect } from "react"
import Header from "@/components/Header"
import HeroSection from "@/components/HeroSection"
import HeroCTA from "@/components/HeroCTA"
import ProblemSection from "@/components/ProblemSection"
import SolutionSection from "@/components/SolutionSection"
import TestimonialsSection from "@/components/TestimonialsSection"
import PricingSection from "@/components/PricingSection"
import GuaranteeSection from "@/components/GuaranteeSection"
import FAQSection from "@/components/FAQSection"
import CTASection from "@/components/CTASection"
import ComparisonTable from "@/components/ComparisonTable"
import Footer from "@/components/Footer"

const Index = () => {
  // Scroll animation handler
  useEffect(() => {
    const handleScroll = () => {
      const elements = document.querySelectorAll(".appear-animation")

      elements.forEach((element) => {
        const rect = element.getBoundingClientRect()
        const isVisible = rect.top <= window.innerHeight * 0.8 && rect.bottom >= 0

        if (isVisible) {
          element.classList.add("shown")
        }
      })
    }

    // Initial check
    setTimeout(handleScroll, 100)

    // Add scroll listener
    window.addEventListener("scroll", handleScroll)

    // Cleanup
    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [])

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-grow">
        <HeroSection />
        <HeroCTA />
        <ProblemSection />
        <SolutionSection />
        <ComparisonTable />
        <TestimonialsSection />
        <GuaranteeSection />
        <PricingSection />
        <FAQSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  )
}

export default Index

