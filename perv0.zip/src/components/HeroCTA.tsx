"use client"

import { useContext } from "react"
import { Button } from "@/components/ui/button"
import { NavigationContext } from "@/App"
import { ArrowRight } from "lucide-react"

const HeroCTA = () => {
  const { navigate } = useContext(NavigationContext)

  // Check if user is authenticated (in a real app, this would be a proper auth check)
  const isAuthenticated = () => {
    return localStorage.getItem("userAuthenticated") === "true"
  }

  const handleCreateBook = () => {
    if (isAuthenticated()) {
      navigate("/dashboard")
    } else {
      navigate("/auth", { returnTo: "/dashboard", action: "new" })
    }
  }

  const handleDiscover = () => {
    if (isAuthenticated()) {
      navigate("/dashboard")
    } else {
      navigate("/auth", { returnTo: "/dashboard", action: null })
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
      <div className="max-w-4xl mx-auto">
        <Button
          onClick={handleCreateBook}
          size="lg"
          className="bg-orange hover:bg-orange-light text-white rounded-full text-base font-semibold px-8 py-6 shadow-md hover:shadow-lg transition-all group pulse-animation"
        >
          <span>🚀 Crea il tuo libro in 5 semplici passaggi</span>
          <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Button>

        <Button
          onClick={handleDiscover}
          variant="link"
          className="text-lg text-orange hover:text-orange-light font-medium mt-6 block mx-auto"
        >
          {isAuthenticated() ? "Il mio account" : "Scopri come funziona"}
        </Button>
      </div>
    </div>
  )
}

export default HeroCTA

