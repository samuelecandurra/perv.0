"use client"

import { useEffect } from "react"

const TestimonialsSection = () => {
  useEffect(() => {
    // Add scroll animation to elements
    const observerOptions = {
      threshold: 0.1,
      rootMargin: "0px 0px -50px 0px",
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("shown")
        }
      })
    }, observerOptions)

    document.querySelectorAll(".appear-animation").forEach((el) => {
      observer.observe(el)
    })

    return () => observer.disconnect()
  }, [])

  return (
    <section
      id="testimonials"
      className="page-section bg-gradient-to-b from-amber-50 to-white relative overflow-hidden"
    >
      {/* Background effect */}
      <div className="absolute inset-0 opacity-50 -z-10">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_20%,rgba(255,153,0,0.05)_0%,rgba(255,255,255,0)_80%)]"></div>
        <div className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(circle_at_70%_80%,rgba(255,153,0,0.05)_0%,rgba(255,255,255,0)_80%)]"></div>
      </div>

      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 appear-animation">
          <h2 className="text-3xl md:text-4xl font-display font-semibold mb-4">Cosa dicono i nostri utenti?</h2>
          <p className="text-xl text-gray-600">
            Non crederci sulla parola. Ecco le esperienze reali di chi utilizza Seribook ogni giorno.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Testimonial 1 */}
          <div className="appear-animation" style={{ transitionDelay: "0.1s" }}>
            <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300 h-full flex flex-col">
              <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden mb-6">
                <img
                  src="https://placehold.co/600x400"
                  alt="Video testimonial thumbnail"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 bg-orange-500/90 rounded-full flex items-center justify-center text-white">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-8 w-8"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                </div>
              </div>
              <blockquote className="text-gray-600 italic mb-6 flex-grow">
                "Ho pubblicato il mio primo libro in meno di una settimana grazie a Seribook. Prima avevo speso mesi
                senza risultati. Il risparmio di tempo è incredibile!"
              </blockquote>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                  <img src="https://placehold.co/200" alt="User" className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="font-semibold">Marco Bianchi</p>
                  <p className="text-sm text-gray-500">Imprenditore digitale</p>
                </div>
              </div>
            </div>
          </div>

          {/* Testimonial 2 */}
          <div className="appear-animation" style={{ transitionDelay: "0.2s" }}>
            <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300 h-full flex flex-col">
              <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden mb-6">
                <img
                  src="https://placehold.co/600x400"
                  alt="Video testimonial thumbnail"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 bg-orange-500/90 rounded-full flex items-center justify-center text-white">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-8 w-8"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                </div>
              </div>
              <blockquote className="text-gray-600 italic mb-6 flex-grow">
                "I template professionali hanno dato ai miei libri un look che prima ottenevo solo pagando un grafico.
                Ora risparmio centinaia di euro per ogni pubblicazione."
              </blockquote>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                  <img src="https://placehold.co/200" alt="User" className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="font-semibold">Alessia Rossi</p>
                  <p className="text-sm text-gray-500">Self-publisher di successo</p>
                </div>
              </div>
            </div>
          </div>

          {/* Testimonial 3 */}
          <div className="appear-animation" style={{ transitionDelay: "0.3s" }}>
            <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300 h-full flex flex-col">
              <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden mb-6">
                <img
                  src="https://placehold.co/600x400"
                  alt="Video testimonial thumbnail"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 bg-orange-500/90 rounded-full flex items-center justify-center text-white">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-8 w-8"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                </div>
              </div>
              <blockquote className="text-gray-600 italic mb-6 flex-grow">
                "Ho creato 12 libri nell'ultimo anno con Seribook. L'editor intelligente migliora automaticamente i
                testi e la qualità finale è sorprendente."
              </blockquote>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                  <img src="https://placehold.co/200" alt="User" className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="font-semibold">Luca Verdi</p>
                  <p className="text-sm text-gray-500">Autore e formatore</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default TestimonialsSection

