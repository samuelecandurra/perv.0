"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"
import SignUpModal from "./ui/SignUpModal"
import { toast } from "sonner"
import { Shield } from "lucide-react"

const PricingSection = () => {
  const [isAnnual, setIsAnnual] = useState(false)

  useEffect(() => {
    // Add scroll animation to elements
    const observerOptions = {
      threshold: 0.1,
      rootMargin: "0px 0px -50px 0px",
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("shown")
        }
      })
    }, observerOptions)

    document.querySelectorAll(".appear-animation").forEach((el) => {
      observer.observe(el)
    })

    return () => observer.disconnect()
  }, [])

  return (
    <section id="pricing" className="page-section relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 opacity-30 -z-10">
        <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(circle_at_70%_20%,rgba(120,119,198,0.1)_0%,rgba(255,255,255,0)_70%)]"></div>
        <div className="absolute bottom-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_80%,rgba(120,119,198,0.1)_0%,rgba(255,255,255,0)_70%)]"></div>
      </div>

      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8 appear-animation">
          <h2 className="text-3xl md:text-4xl font-display font-semibold mb-4">
            Scegli il piano più adatto al tuo business editoriale
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Soluzione flessibile per ogni fase del tuo percorso da self-publisher.
          </p>
        </div>

        {/* Guarantee section moved above pricing plans */}
        <div className="mb-12 appear-animation flex justify-center">
          <div className="max-w-[700px] bg-orange-soft border border-orange rounded-[20px] p-6 shadow-[0_8px_30px_rgba(0,0,0,0.05)] flex flex-col md:flex-row items-start md:items-center gap-5 w-full">
            <div className="shrink-0 w-14 h-14 mx-auto md:mx-0 flex items-center justify-center bg-white/50 rounded-full">
              <Shield className="h-7 w-7 text-orange" />
            </div>

            <div className="text-center md:text-left">
              <h3 className="font-bold text-deep-black text-xl mb-3">
                La nostra AI scrive come un autore umano, non come un bot.
              </h3>
              <p className="text-deep-black text-base md:text-lg leading-relaxed">
                Tutti i libri creati con Seribook sono originali, verificati e pronti per la pubblicazione.
                <br className="hidden md:block" />
                <span className="font-semibold">Se una piattaforma lo blocca, ti rimborsiamo. Senza domande.</span>
              </p>
            </div>
          </div>
        </div>

        {/* Centered Monthly/Annual toggle with updated styling */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex items-center bg-gray-100 p-1 rounded-full">
            <button
              className={`py-2 px-8 rounded-full text-sm font-medium transition-all duration-200 ${!isAnnual ? "bg-white shadow-md text-blue-600" : "text-gray-600 hover:text-gray-900"}`}
              onClick={() => setIsAnnual(false)}
            >
              Mensile
            </button>
            <button
              className={`py-2 px-8 rounded-full text-sm font-medium transition-all duration-200 ${isAnnual ? "bg-white shadow-md text-blue-600" : "text-gray-600 hover:text-gray-900"}`}
              onClick={() => setIsAnnual(true)}
            >
              Annuale <span className="text-green-600 font-bold">-20%</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Una Tantum Plan */}
          <div className="appear-animation" style={{ transitionDelay: "0.1s" }}>
            <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 h-full">
              <div className="p-8">
                <h3 className="text-xl font-bold mb-4">Una Tantum</h3>
                <div className="mb-6">
                  <span className="text-4xl font-bold">€39</span>
                  <span className="text-gray-500 ml-2">una tantum</span>
                </div>
                <p className="text-gray-600 mb-6">
                  Perfetto per chi vuole creare un singolo libro senza abbonamenti ricorrenti.
                </p>

                <ul className="space-y-3 mb-8">
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>
                      <span className="font-medium">Da 10.000 a 50.000+</span> parole
                    </span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Formattazione personalizzata</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Editor AI con rigenerazioni</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Controllo anti-plagio</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Supporto email</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Pagamento singolo</span>
                  </li>
                </ul>
              </div>

              <div className="p-8 bg-gray-50 mt-auto">
                <Button
                  variant="outline"
                  className="w-full hover:bg-gray-100"
                  onClick={() => toast.success("Acquisto Una Tantum avviato!")}
                >
                  Acquista ora
                </Button>
              </div>
            </div>
          </div>

          {/* Pro Plan */}
          <div className="appear-animation -mt-4 md:mt-0" style={{ transitionDelay: "0.2s" }}>
            <div className="relative bg-white rounded-2xl overflow-hidden shadow-xl border-2 border-blue-500 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 h-full">
              <div className="absolute top-0 right-0 bg-blue-600 text-white px-4 py-1 rounded-bl-lg font-medium text-sm">
                Più scelto
              </div>
              <div className="p-8">
                <h3 className="text-xl font-bold mb-4">Pro</h3>
                <div className="mb-6">
                  <span className="text-4xl font-bold">€59</span>
                  <span className="text-gray-500 ml-2">una tantum</span>
                </div>
                <p className="text-gray-600 mb-6">
                  Ideale per ebook completi, manuali base e pubblicazioni di media lunghezza.
                </p>

                <ul className="space-y-3 mb-8">
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>
                      <span className="font-medium">25.000 parole</span> per libro
                    </span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>
                      Solo <span className="font-medium">€0,00236</span> per parola
                    </span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Da 10.000 a 50.000+ parole</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Editor AI avanzato</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Controllo anti-plagio</span>
                  </li>
                </ul>
              </div>

              <div className="p-8 bg-blue-50 mt-auto">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-full">
                      Acquista ora
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <SignUpModal />
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </div>

          {/* Premium Plan */}
          <div className="appear-animation" style={{ transitionDelay: "0.3s" }}>
            <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 h-full">
              <div className="p-8">
                <h3 className="text-xl font-bold mb-4">Premium</h3>
                <div className="mb-6">
                  <span className="text-4xl font-bold">€99</span>
                  <span className="text-gray-500 ml-2">una tantum</span>
                </div>
                <p className="text-gray-600 mb-6">
                  Perfetto per libri lunghi, saggi, serie e contenuti complessi di ampio respiro.
                </p>

                <ul className="space-y-3 mb-8">
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>
                      <span className="font-medium">50.000 parole</span> per libro
                    </span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>
                      Solo <span className="font-medium">€0,00198</span> per parola
                    </span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Da 10.000 a 50.000+ parole</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Assistenza AI completa</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Controllo anti-plagio</span>
                  </li>
                </ul>
              </div>

              <div className="p-8 bg-gray-50 mt-auto">
                <Button
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-full"
                  onClick={() => toast.success("Acquisto Premium avviato!")}
                >
                  Acquista ora
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-10 text-center">
          <div className="inline-flex items-center bg-green-100 text-green-800 px-4 py-2 rounded-full">
            <svg className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
              />
            </svg>
            <span className="font-medium">Soddisfatti o rimborsati entro 7 giorni</span>
          </div>
        </div>
      </div>
    </section>
  )
}

export default PricingSection

