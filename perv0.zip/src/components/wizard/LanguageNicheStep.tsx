"use client"

import { useState, useEffect } from "react"
import WizardButtons from "./WizardButtons"

import LanguageSelector from "./language-niche/LanguageSelector"
import NicheSelector from "./language-niche/NicheSelector"
import CookingNicheDetails from "./language-niche/CookingNicheDetails"
import EducationNicheDetails from "./language-niche/EducationNicheDetails"
import SelfHelpNicheDetails from "./language-niche/SelfHelpNicheDetails"
import BusinessNicheDetails from "./language-niche/BusinessNicheDetails"
import FictionNicheDetails from "./language-niche/FictionNicheDetails"
import HowToNicheDetails from "./language-niche/HowToNicheDetails"
import { isCookingNiche } from "./language-niche/utils"

interface LanguageNicheStepProps {
  onUpdate: (data: { language: string; niche: string }) => void
  onNext: () => void
  onBack: () => void
  bookData: {
    language: string
    niche: string
  }
}

const LanguageNicheStep = ({ onUpdate, onNext, onBack, bookData }: LanguageNicheStepProps) => {
  const isNextDisabled = !bookData.language || !bookData.niche
  const [recipeSchema, setRecipeSchema] = useState("auto")
  const [customRecipeSchema, setCustomRecipeSchema] = useState("")
  const [recipeCount, setRecipeCount] = useState<number | "">("")
  const [quizCount, setQuizCount] = useState<number | "">("")
  const [exerciseCount, setExerciseCount] = useState<number | "">("")
  const [caseStudyCount, setCaseStudyCount] = useState<number | "">("")
  const [chapterCount, setChapterCount] = useState<number | "">("")

  // Reset recipe schema when changing away from cookbook niche
  useEffect(() => {
    if (!isCookingNiche(bookData.niche)) {
      setRecipeSchema("auto")
      setCustomRecipeSchema("")
    }
  }, [bookData.niche])

  const handleLanguageChange = (value: string) => {
    onUpdate({ language: value, niche: bookData.niche })
  }

  const handleNicheChange = (value: string) => {
    onUpdate({ language: bookData.language, niche: value })
  }

  return (
    <div className="bg-white p-6">
      <h2 className="text-2xl md:text-3xl font-semibold mb-2">Lingua e Nicchia</h2>
      <p className="text-muted-foreground mb-10">Seleziona la lingua del tuo libro e la nicchia a cui appartiene</p>

      <div className="space-y-8">
        <LanguageSelector language={bookData.language} onLanguageChange={handleLanguageChange} />

        <NicheSelector niche={bookData.niche} onNicheChange={handleNicheChange} />

        {isCookingNiche(bookData.niche) && (
          <CookingNicheDetails
            recipeCount={recipeCount}
            setRecipeCount={setRecipeCount}
            recipeSchema={recipeSchema}
            setRecipeSchema={setRecipeSchema}
            customRecipeSchema={customRecipeSchema}
            setCustomRecipeSchema={setCustomRecipeSchema}
          />
        )}

        {bookData.niche === "education" && <EducationNicheDetails quizCount={quizCount} setQuizCount={setQuizCount} />}

        {bookData.niche === "selfhelp" && (
          <SelfHelpNicheDetails exerciseCount={exerciseCount} setExerciseCount={setExerciseCount} />
        )}

        {bookData.niche === "business" && (
          <BusinessNicheDetails caseStudyCount={caseStudyCount} setCaseStudyCount={setCaseStudyCount} />
        )}

        {bookData.niche === "fiction" && (
          <FictionNicheDetails chapterCount={chapterCount} setChapterCount={setChapterCount} />
        )}

        {bookData.niche === "howto" && (
          <HowToNicheDetails exerciseCount={exerciseCount} setExerciseCount={setExerciseCount} />
        )}
      </div>

      <WizardButtons onNext={onNext} onBack={onBack} isNextDisabled={isNextDisabled} />
    </div>
  )
}

export default LanguageNicheStep

