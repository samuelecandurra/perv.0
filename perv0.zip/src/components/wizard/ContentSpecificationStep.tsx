"use client"

import type React from "react"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import WizardButtons from "./WizardButtons"
import { Sparkles, Info } from "lucide-react"

interface ContentSpecificationStepProps {
  onUpdate: (
    data: Partial<{
      tone: string
      audience: string
      description: string
      uniqueSellingPoint: string
      graphicTemplate: string
      colorScheme: string
      includeImages: string
      imageCount: string
    }>,
  ) => void
  onNext: () => void
  onBack: () => void
  bookData: {
    tone: string
    audience: string
    description: string
    uniqueSellingPoint: string
    graphicTemplate: string
    colorScheme: string
    includeImages: string
    imageCount: string
  }
}

const ContentSpecificationStep = ({ onUpdate, onNext, onBack, bookData }: ContentSpecificationStepProps) => {
  const isNextDisabled = !bookData.tone || !bookData.audience || !bookData.description

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>) => {
    const { name, value } = e.target
    onUpdate({ [name]: value })
  }

  // Esempi per la descrizione del libro
  const descriptionExamples = [
    "Una guida completa per principianti sul trading di criptovalute",
    "Un manuale per imparare a cucinare piatti tradizionali italiani",
    "Storia e tecniche della fotografia moderna",
    "Metodologie di apprendimento per studiare le lingue straniere",
  ]

  // Esempi di punti di forza unici
  const uniqueSellingPointExamples = [
    "Include 500 quiz per prepararti al concorso",
    "Con 30 ricette detox testate dallo chef",
    "Ogni capitolo termina con un esercizio pratico",
    "Contiene 10 casi studio di aziende di successo",
    "Interviste esclusive con 15 esperti del settore",
    "Book includes 5 Full-length Linear Digital SAT® Practice Tests",
    "150 Days Easy, Delicious & Nutritious Recipes Book for Balanced Eating",
    "30-Day Meal Plan to Get Started",
  ]

  return (
    <div className="space-y-8 font-['Canela',_'Playfair_Display',_Georgia,_serif]">
      <div className="text-center space-y-2 max-w-3xl mx-auto">
        <h1 className="text-3xl font-heading font-bold text-gray-900">Tono e Pubblico Target</h1>
      </div>

      <div className="max-w-3xl mx-auto space-y-6">
        <div className="relative border border-gray-100 rounded-lg bg-white p-6 shadow-sm">
          {/* Blue vertical accent bar */}
          <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#0EA5E9] rounded-l-lg"></div>

          <div className="pl-4 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="tone" className="text-base font-medium">
                Tono del contenuto:
              </Label>
              <Select value={bookData.tone} onValueChange={(value) => onUpdate({ tone: value })}>
                <SelectTrigger
                  id="tone"
                  className="w-full bg-white border-gray-200 focus:border-[#0EA5E9] focus:ring-[#0EA5E9]"
                >
                  <SelectValue placeholder="Seleziona il tono" />
                </SelectTrigger>
                <SelectContent className="bg-white">
                  <SelectItem value="professional">Professionale</SelectItem>
                  <SelectItem value="casual">Informale</SelectItem>
                  <SelectItem value="academic">Accademico</SelectItem>
                  <SelectItem value="humorous">Umoristico</SelectItem>
                  <SelectItem value="inspirational">Motivazionale</SelectItem>
                  <SelectItem value="authoritative">Autorevole</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="audience" className="text-base font-medium">
                Pubblico target:
              </Label>
              <Select value={bookData.audience} onValueChange={(value) => onUpdate({ audience: value })}>
                <SelectTrigger
                  id="audience"
                  className="w-full bg-white border-gray-200 focus:border-[#0EA5E9] focus:ring-[#0EA5E9]"
                >
                  <SelectValue placeholder="Seleziona il pubblico target" />
                </SelectTrigger>
                <SelectContent className="bg-white">
                  <SelectItem value="beginners">Principianti</SelectItem>
                  <SelectItem value="intermediate">Livello intermedio</SelectItem>
                  <SelectItem value="advanced">Livello avanzato</SelectItem>
                  <SelectItem value="professionals">Professionisti</SelectItem>
                  <SelectItem value="general">Pubblico generico</SelectItem>
                  <SelectItem value="children">Bambini</SelectItem>
                  <SelectItem value="teenagers">Adolescenti</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Improve Your Book Content section - without quizzes */}
        <div className="relative border border-gray-100 rounded-lg bg-white p-6 shadow-sm">
          {/* Blue vertical accent bar */}
          <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#0EA5E9] rounded-l-lg"></div>

          <div className="pl-4">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="h-5 w-5 text-[#0EA5E9]" />
              <h2 className="text-xl font-bold font-heading text-gray-900">Migliora il contenuto del tuo libro</h2>
            </div>

            <p className="text-gray-700 mb-4">
              Personalizza il tuo libro con questi elementi per renderlo più coinvolgente e di valore per i lettori.
            </p>

            <div className="space-y-2">
              <Label htmlFor="includeImages" className="text-base font-medium">
                Include immagini nel libro?
              </Label>
              <Select value={bookData.includeImages} onValueChange={(value) => onUpdate({ includeImages: value })}>
                <SelectTrigger
                  id="includeImages"
                  className="w-full bg-white border-gray-200 focus:border-[#0EA5E9] focus:ring-[#0EA5E9]"
                >
                  <SelectValue placeholder="Seleziona opzione" />
                </SelectTrigger>
                <SelectContent className="bg-white">
                  <SelectItem value="none">Nessuna immagine</SelectItem>
                  <SelectItem value="photos">Foto realistiche</SelectItem>
                  <SelectItem value="illustrations">Disegni/Illustrazioni</SelectItem>
                  <SelectItem value="diagrams">Diagrammi</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-gray-500 mt-1">Le immagini rendono il contenuto più chiaro e memorabile</p>
            </div>

            {bookData.includeImages && bookData.includeImages !== "none" && (
              <div className="space-y-2 mt-4">
                <Label htmlFor="imageCount" className="text-base font-medium">
                  Quante immagini vuoi includere?
                </Label>
                <Input
                  id="imageCount"
                  name="imageCount"
                  type="number"
                  placeholder="Es. 10"
                  value={bookData.imageCount || ""}
                  onChange={handleChange}
                  className="bg-white border-gray-200 focus:border-[#0EA5E9] focus:ring-[#0EA5E9]"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Un numero maggiore di immagini può aumentare il costo di produzione.
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="relative border border-gray-100 rounded-lg bg-white p-6 shadow-sm">
          {/* Blue vertical accent bar */}
          <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#0EA5E9] rounded-l-lg"></div>

          <div className="pl-4 space-y-6">
            <h2 className="text-xl font-bold font-heading text-gray-900">Descrizione del Contenuto</h2>

            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="description" className="text-base font-medium">
                  Descrivi cosa vuoi che il tuo libro contenga:
                </Label>
                <Textarea
                  id="description"
                  name="description"
                  rows={4}
                  placeholder="Descrivi gli argomenti principali, i problemi che risolve, ecc."
                  value={bookData.description}
                  onChange={handleChange}
                  className="w-full bg-white border-gray-200 resize-y min-h-[120px] focus:border-[#0EA5E9] focus:ring-[#0EA5E9]"
                />

                <div className="mt-3 bg-blue-50 border border-blue-100 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-2 text-blue-700">
                    <Info className="h-4 w-4" />
                    <p className="text-sm font-medium">Esempi di descrizioni efficaci:</p>
                  </div>
                  <div className="space-y-2">
                    {descriptionExamples.map((example, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <div className="text-blue-500 mt-0.5">•</div>
                        <p className="text-sm text-blue-700">{example}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="uniqueSellingPoint" className="text-base font-medium">
                  Cosa rende il tuo libro unico?
                </Label>
                <Textarea
                  id="uniqueSellingPoint"
                  name="uniqueSellingPoint"
                  rows={4}
                  placeholder="Descrivi cosa distingue il tuo libro dagli altri"
                  value={bookData.uniqueSellingPoint}
                  onChange={handleChange}
                  className="w-full bg-white border-gray-200 resize-y focus:border-[#0EA5E9] focus:ring-[#0EA5E9]"
                />

                <div className="mt-3 bg-green-50 border border-green-100 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-2 text-green-700">
                    <Sparkles className="h-4 w-4" />
                    <p className="text-sm font-medium">Suggerimenti per rendere il tuo libro unico:</p>
                  </div>
                  <div className="space-y-2">
                    {uniqueSellingPointExamples.map((example, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <div className="text-green-600 mt-0.5">•</div>
                        <p className="text-sm text-green-700">{example}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="relative border border-gray-100 rounded-lg bg-white p-6 shadow-sm">
          {/* Blue vertical accent bar */}
          <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#0EA5E9] rounded-l-lg"></div>

          <div className="pl-4 space-y-6">
            <h2 className="text-xl font-bold text-gray-900">Formato e Stile</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="graphicTemplate" className="text-base font-medium">
                  Template grafico:
                </Label>
                <Select
                  value={bookData.graphicTemplate}
                  onValueChange={(value) => onUpdate({ graphicTemplate: value })}
                >
                  <SelectTrigger
                    id="graphicTemplate"
                    className="w-full bg-white border-gray-200 focus:border-[#0EA5E9] focus:ring-[#0EA5E9]"
                  >
                    <SelectValue placeholder="Seleziona template" />
                  </SelectTrigger>
                  <SelectContent className="bg-white">
                    <SelectItem value="none">Nessun template (solo testo)</SelectItem>
                    <SelectItem value="professional">Professionale</SelectItem>
                    <SelectItem value="academic">Accademico</SelectItem>
                    <SelectItem value="creative">Creativo</SelectItem>
                    <SelectItem value="minimal">Minimale</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="colorScheme" className="text-base font-medium">
                  Schema colori:
                </Label>
                <Select value={bookData.colorScheme} onValueChange={(value) => onUpdate({ colorScheme: value })}>
                  <SelectTrigger
                    id="colorScheme"
                    className="w-full bg-white border-gray-200 focus:border-[#0EA5E9] focus:ring-[#0EA5E9]"
                  >
                    <SelectValue placeholder="Seleziona schema colori" />
                  </SelectTrigger>
                  <SelectContent className="bg-white">
                    <SelectItem value="blue">Blu</SelectItem>
                    <SelectItem value="green">Verde</SelectItem>
                    <SelectItem value="purple">Viola</SelectItem>
                    <SelectItem value="orange">Arancione</SelectItem>
                    <SelectItem value="gray">Grigio</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </div>
      </div>

      <WizardButtons onNext={onNext} onBack={onBack} isNextDisabled={isNextDisabled} />
    </div>
  )
}

export default ContentSpecificationStep

