"use client"

import type React from "react"
import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import WizardButtons from "./WizardButtons"
import BookDetailsHeader from "./book-details/BookDetailsHeader"
import BookTypeCard from "./book-details/BookTypeCard"
import BookInfoCard from "./book-details/BookInfoCard"
import BookPreviewCard from "./book-details/BookPreviewCard"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"

interface BookDetailsStepProps {
  onUpdate: (
    data: Partial<{
      type: string
      language: string
      niche: string
      title: string
      subtitle: string
      wordCount: string
      format: string
      trimWidth: string
      trimHeight: string
      includeImages: string
      imageCount: number
      contentDetails: {
        recipeCount?: number
        quizCount?: number
        exerciseCount?: number
        caseStudyCount?: number
        chapterCount?: number
      }
      bonusContent: { title: string; description: string }[]
    }>,
  ) => void
  onNext: () => void
  bookData: {
    type: string
    language: string
    niche: string
    title: string
    subtitle: string
    wordCount: string
    format: string
    trimWidth: string
    trimHeight: string
    includeImages: string
    imageCount: number
    contentDetails: {
      recipeCount?: number
      quizCount?: number
      exerciseCount?: number
      caseStudyCount?: number
      chapterCount?: number
    }
    bonusContent?: { title: string; description: string }[]
  }
}

const BookDetailsStep = ({ onUpdate, onNext, bookData }: BookDetailsStepProps) => {
  const isNextDisabled =
    !bookData.type || !bookData.language || !bookData.niche || !bookData.title || !bookData.wordCount
  const [activeTab, setActiveTab] = useState("form")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    onUpdate({ [name]: value })
  }

  return (
    <div className="space-y-8 font-['Inter',_'SF_Pro_Text',_-apple-system,_BlinkMacSystemFont,_'Segoe_UI',_Roboto,_'Helvetica_Neue',_Arial,_sans-serif]">
      <BookDetailsHeader />

      <Tabs defaultValue="form" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-2 mb-6">
          <TabsTrigger
            value="form"
            className="font-['Inter',_'SF_Pro_Text',_-apple-system,_BlinkMacSystemFont,_'Segoe_UI',_Roboto,_'Helvetica_Neue',_Arial,_sans-serif]"
          >
            Form View
          </TabsTrigger>
          <TabsTrigger
            value="preview"
            className="font-['Inter',_'SF_Pro_Text',_-apple-system,_BlinkMacSystemFont,_'Segoe_UI',_Roboto,_'Helvetica_Neue',_Arial,_sans-serif]"
          >
            Preview
          </TabsTrigger>
        </TabsList>

        <TabsContent value="form" className="space-y-6">
          <BookTypeCard
            bookType={bookData.type}
            language={bookData.language}
            niche={bookData.niche}
            contentDetails={bookData.contentDetails}
            onUpdate={onUpdate}
          />

          <BookInfoCard
            title={bookData.title}
            subtitle={bookData.subtitle}
            wordCount={bookData.wordCount}
            niche={bookData.niche}
            onUpdate={onUpdate}
            handleChange={handleChange}
          />

          {/* Added Image Selection Section */}
          <div className="p-6 bg-white">
            <h2 className="text-2xl font-bold mb-6">Images (Optional)</h2>

            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="includeImages">Include images in your ebook?</Label>
                <Select value={bookData.includeImages} onValueChange={(value) => onUpdate({ includeImages: value })}>
                  <SelectTrigger id="includeImages" className="w-full">
                    <SelectValue placeholder="Select option" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No images</SelectItem>
                    <SelectItem value="photos">Realistic photos</SelectItem>
                    <SelectItem value="illustrations">Drawings/Illustrations</SelectItem>
                    <SelectItem value="diagrams">Diagrams</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground">Images will consume credits from your account.</p>
              </div>

              {bookData.includeImages && bookData.includeImages !== "none" && (
                <div className="space-y-2 mt-4">
                  <Label htmlFor="imageCount">
                    Number of images: <span className="font-medium ml-2">{bookData.imageCount || 10}</span>
                  </Label>
                  <Slider
                    id="imageCount"
                    min={5}
                    max={50}
                    step={5}
                    value={[bookData.imageCount || 10]}
                    onValueChange={(values) => onUpdate({ imageCount: values[0] })}
                    className="w-full"
                  />
                  <p className="text-sm text-muted-foreground">Selecting more images will use more image credits.</p>
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="preview">
          <BookPreviewCard bookData={bookData} onReturn={() => setActiveTab("form")} />
        </TabsContent>
      </Tabs>

      <WizardButtons onNext={onNext} isNextDisabled={isNextDisabled} nextLabel="Continue" />
    </div>
  )
}

export default BookDetailsStep

