"use client"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

interface LanguageSelectorProps {
  language: string
  onLanguageChange: (value: string) => void
}

const LanguageSelector = ({ language, onLanguageChange }: LanguageSelectorProps) => {
  const languages = [
    { value: "it", label: "Italiano" },
    { value: "en", label: "Inglese" },
    { value: "es", label: "Spagnolo" },
    { value: "fr", label: "Francese" },
    { value: "de", label: "Tedesco" },
  ]

  return (
    <div className="space-y-4">
      <Label htmlFor="language">Lingua del libro</Label>
      <Select value={language} onValueChange={onLanguageChange}>
        <SelectTrigger id="language" className="w-full bg-white">
          <SelectValue placeholder="Seleziona la lingua del libro" />
        </SelectTrigger>
        <SelectContent className="bg-white">
          {languages.map((language) => (
            <SelectItem key={language.value} value={language.value}>
              {language.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

export default LanguageSelector

