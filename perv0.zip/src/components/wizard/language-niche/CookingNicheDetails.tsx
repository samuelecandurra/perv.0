"use client"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle } from "lucide-react"

interface CookingNicheDetailsProps {
  recipeCount: number | ""
  setRecipeCount: (value: number | "") => void
  recipeSchema: string
  setRecipeSchema: (value: string) => void
  customRecipeSchema: string
  setCustomRecipeSchema: (value: string) => void
}

const CookingNicheDetails = ({
  recipeCount,
  setRecipeCount,
  recipeSchema,
  setRecipeSchema,
  customRecipeSchema,
  setCustomRecipeSchema,
}: CookingNicheDetailsProps) => {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="recipeCount" className="text-sm text-blue-800">
          Quante ricette vuoi includere nel libro?
        </Label>
        <Input
          id="recipeCount"
          type="number"
          className="bg-white border-blue-200"
          min={1}
          value={recipeCount}
          onChange={(e) => setRecipeCount(e.target.value ? Number.parseInt(e.target.value) : "")}
          placeholder="Es. 50"
        />
        <p className="text-xs text-blue-600">Consigliato: 30-100 ricette per un libro completo</p>
      </div>

      <div className="space-y-3">
        <Label htmlFor="recipeSchema" className="text-sm text-blue-800">
          Schema delle ricette
        </Label>

        <div className="grid grid-cols-1 gap-2">
          <div className="flex items-center space-x-2">
            <input
              type="radio"
              id="auto"
              name="recipeSchema"
              value="auto"
              checked={recipeSchema === "auto"}
              onChange={() => setRecipeSchema("auto")}
              className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
            />
            <label htmlFor="auto" className="text-sm font-medium text-blue-800">
              Schema automatico (ottimizzato per libri di cucina)
            </label>
          </div>

          <div className="flex items-center space-x-2">
            <input
              type="radio"
              id="custom"
              name="recipeSchema"
              value="custom"
              checked={recipeSchema === "custom"}
              onChange={() => setRecipeSchema("custom")}
              className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
            />
            <label htmlFor="custom" className="text-sm font-medium text-blue-800">
              Schema personalizzato
            </label>
          </div>
        </div>

        {recipeSchema === "custom" && (
          <div className="mt-3 space-y-2">
            <div className="bg-gray-100 border border-gray-200 p-3 rounded-md text-gray-700 text-sm">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="h-4 w-4 text-gray-600" />
                <span className="font-medium">
                  Ogni volta che richiedi "ricette" nell'indice qui sotto, il testo seguirà questo schema
                </span>
              </div>
              <Textarea
                placeholder="esempio: ingredienti, tempo di preparazione, istruzioni, grado di difficoltà."
                className="mt-2 h-20 text-sm bg-white"
                value={customRecipeSchema}
                onChange={(e) => setCustomRecipeSchema(e.target.value)}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default CookingNicheDetails

