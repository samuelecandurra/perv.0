"use client"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

interface NicheSelectorProps {
  niche: string
  onNicheChange: (value: string) => void
}

const NicheSelector = ({ niche, onNicheChange }: NicheSelectorProps) => {
  const niches = [
    { value: "cookbook", label: "Ricettario" },
    { value: "cucina", label: "Cucina" },
    { value: "education", label: "Educazione" },
    { value: "business", label: "Business" },
    { value: "fiction", label: "Narrativa" },
    { value: "selfhelp", label: "Self-Help" },
    { value: "howto", label: "Guide Pratiche" },
    { value: "children", label: "Libri per Bambini" },
  ]

  return (
    <div className="space-y-4">
      <Label htmlFor="niche">Nicchia del libro</Label>
      <Select value={niche} onValueChange={onNicheChange}>
        <SelectTrigger id="niche" className="w-full bg-white">
          <SelectValue placeholder="Seleziona la nicchia del libro" />
        </SelectTrigger>
        <SelectContent className="bg-white">
          {niches.map((niche) => (
            <SelectItem key={niche.value} value={niche.value}>
              {niche.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

export default NicheSelector

