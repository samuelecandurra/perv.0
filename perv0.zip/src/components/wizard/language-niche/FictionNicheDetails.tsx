"use client"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Info } from "lucide-react"

interface FictionNicheDetailsProps {
  chapterCount: number | ""
  setChapterCount: (value: number | "") => void
}

const FictionNicheDetails = ({ chapterCount, setChapterCount }: FictionNicheDetailsProps) => {
  return (
    <div className="p-4 bg-blue-50 border border-blue-100 rounded-lg space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <Info className="h-5 w-5 text-blue-600" />
        <h3 className="font-medium text-blue-800">Dettagli del contenuto</h3>
      </div>

      <p className="text-sm text-blue-700 font-medium">Questa parte è determinante per il contenuto del tuo libro.</p>

      <div className="space-y-2">
        <Label htmlFor="chapterCount" className="text-sm text-blue-800">
          Quanti capitoli vuoi che abbia il libro?
        </Label>
        <Input
          id="chapterCount"
          type="number"
          className="bg-white border-blue-200"
          min={1}
          value={chapterCount}
          onChange={(e) => setChapterCount(e.target.value ? Number.parseInt(e.target.value) : "")}
          placeholder="Es. 12"
        />
        <p className="text-xs text-blue-600">
          La struttura a capitoli aiuta a organizzare il contenuto in modo più chiaro
        </p>
      </div>
    </div>
  )
}

export default FictionNicheDetails

