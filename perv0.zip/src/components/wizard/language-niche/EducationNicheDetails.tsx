"use client"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Info } from "lucide-react"

interface EducationNicheDetailsProps {
  quizCount: number | ""
  setQuizCount: (value: number | "") => void
}

const EducationNicheDetails = ({ quizCount, setQuizCount }: EducationNicheDetailsProps) => {
  return (
    <div className="p-4 bg-blue-50 border border-blue-100 rounded-lg space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <Info className="h-5 w-5 text-blue-600" />
        <h3 className="font-medium text-blue-800">Dettagli del contenuto</h3>
      </div>

      <p className="text-sm text-blue-700 font-medium">Questa parte è determinante per il contenuto del tuo libro.</p>

      <div className="space-y-2">
        <Label htmlFor="quizCount" className="text-sm text-blue-800">
          Quanti quiz o test vuoi includere?
        </Label>
        <Input
          id="quizCount"
          type="number"
          className="bg-white border-blue-200"
          min={0}
          value={quizCount}
          onChange={(e) => setQuizCount(e.target.value ? Number.parseInt(e.target.value) : "")}
          placeholder="Es. 10"
        />
        <p className="text-xs text-blue-600">I quiz aiutano a rafforzare l'apprendimento e valutare la comprensione</p>
      </div>
    </div>
  )
}

export default EducationNicheDetails

