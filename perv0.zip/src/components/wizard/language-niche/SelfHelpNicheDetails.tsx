"use client"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Info } from "lucide-react"

interface SelfHelpNicheDetailsProps {
  exerciseCount: number | ""
  setExerciseCount: (value: number | "") => void
}

const SelfHelpNicheDetails = ({ exerciseCount, setExerciseCount }: SelfHelpNicheDetailsProps) => {
  return (
    <div className="p-4 bg-blue-50 border border-blue-100 rounded-lg space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <Info className="h-5 w-5 text-blue-600" />
        <h3 className="font-medium text-blue-800">Dettagli del contenuto</h3>
      </div>

      <p className="text-sm text-blue-700 font-medium">Questa parte è determinante per il contenuto del tuo libro.</p>

      <div className="space-y-2">
        <Label htmlFor="exerciseCount" className="text-sm text-blue-800">
          Quanti esercizi pratici vuoi includere?
        </Label>
        <Input
          id="exerciseCount"
          type="number"
          className="bg-white border-blue-200"
          min={0}
          value={exerciseCount}
          onChange={(e) => setExerciseCount(e.target.value ? Number.parseInt(e.target.value) : "")}
          placeholder="Es. 15"
        />
        <p className="text-xs text-blue-600">Gli esercizi pratici rendono il libro più interattivo e utile</p>
      </div>
    </div>
  )
}

export default SelfHelpNicheDetails

