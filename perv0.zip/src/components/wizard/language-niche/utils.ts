/**
 * Helper function to check if the niche is cooking-related
 */
export const isCookingNiche = (niche: string): boolean => {
  return niche === "cookbook" || niche === "cucina"
}

