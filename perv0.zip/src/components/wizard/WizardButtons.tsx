"use client"
import { ArrowRight, ArrowLeft } from "lucide-react"

interface WizardButtonsProps {
  onNext: () => void
  onBack?: () => void
  nextLabel?: string
  backLabel?: string
  isLastStep?: boolean
  isNextDisabled?: boolean
}

const WizardButtons = ({
  onNext,
  onBack,
  nextLabel = "Avanti",
  backLabel = "Indietro",
  isLastStep = false,
  isNextDisabled = false,
}: WizardButtonsProps) => {
  return (
    <div className="flex justify-between mt-10 font-['Canela',_'Playfair_Display',_Georgia,_serif]">
      {onBack ? (
        <button
          onClick={onBack}
          className="flex items-center px-5 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          {backLabel}
        </button>
      ) : (
        <div></div>
      )}

      <button
        onClick={onNext}
        disabled={isNextDisabled}
        className="flex items-center px-5 py-2.5 bg-[#FF9900] hover:bg-[#FF9900]/90 rounded-lg text-sm font-medium text-white shadow-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLastStep ? "Completa" : nextLabel}
        <ArrowRight className="h-4 w-4 ml-2" />
      </button>
    </div>
  )
}

export default WizardButtons

