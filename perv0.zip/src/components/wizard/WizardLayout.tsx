"use client"

import type React from "react"
import { useContext } from "react"
import { ArrowLeft } from "lucide-react"
import { NavigationContext } from "@/App"
import Link from "@/components/ui/Link"

interface WizardLayoutProps {
  children: React.ReactNode
}

const WizardLayout = ({ children }: WizardLayoutProps) => {
  const { navigate } = useContext(NavigationContext)

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex">
      <div className="flex-1">
        <div className="container max-w-4xl mx-auto px-4 py-8">
          <div className="mb-8 flex items-center justify-between">
            <a
              href="#"
              className="inline-flex items-center text-[#333333]/70 hover:text-[#333333] transition-colors"
              onClick={() => navigate("/")}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to home
            </a>
            <Link to="/" className="flex items-center">
              <img
                src="/lovable-uploads/ac709032-b968-4d6c-b151-99aa574cad77.png"
                alt="Seribook Logo"
                className="h-8"
              />
            </Link>
          </div>

          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="flex">
              {/* Position the blue accent line inside the white area */}
              <div className="w-1.5 bg-[#0EA5E9] self-stretch"></div>
              <div className="flex-1 p-6 font-['Canela',_'Playfair_Display',_Georgia,_serif]">{children}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default WizardLayout

