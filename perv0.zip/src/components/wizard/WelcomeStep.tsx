"use client"
import { BookOpen, Edit3 } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface WelcomeStepProps {
  onSelect: (type: string) => void
  onNext: () => void
  bookData: {
    type: string
  }
}

const WelcomeStep = ({ onSelect, onNext, bookData }: WelcomeStepProps) => {
  const handleSelect = (type: string) => {
    onSelect(type)
    onNext()
  }

  return (
    <div className="text-center font-['Inter',_'SF_Pro_Text',_-apple-system,_BlinkMacSystemFont,_'Segoe_UI',_Roboto,_'Helvetica_Neue',_Arial,_sans-serif]">
      <h1 className="text-3xl md:text-4xl font-semibold mb-4">Crea il tuo prossimo libro in 5 minuti</h1>
      <p className="text-xl text-muted-foreground mb-12">
        Seribook ti aiuta a creare libri professionali e pronti per la pubblicazione in pochi minuti
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
        <Card
          className={`cursor-pointer hover-lift transition-all duration-300 ${
            bookData.type === "new" ? "border-primary ring-2 ring-primary ring-opacity-50" : ""
          }`}
          onClick={() => handleSelect("new")}
        >
          <CardContent className="p-8 flex flex-col items-center">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <BookOpen className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Inizia un nuovo libro</h3>
            <p className="text-muted-foreground">Crea un libro da zero con il nostro assistente guidato</p>
          </CardContent>
        </Card>

        <Card
          className={`cursor-pointer hover-lift transition-all duration-300 ${
            bookData.type === "improve" ? "border-primary ring-2 ring-primary ring-opacity-50" : ""
          }`}
          onClick={() => handleSelect("improve")}
        >
          <CardContent className="p-8 flex flex-col items-center">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Edit3 className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Migliora un libro esistente</h3>
            <p className="text-muted-foreground">Carica un libro esistente per migliorarne la qualità con l'AI</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default WelcomeStep

