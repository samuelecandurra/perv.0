import { Progress } from "@/components/ui/progress"

interface StepIndicatorProps {
  currentStep: number
  totalSteps: number
}

const StepIndicator = ({ currentStep, totalSteps }: StepIndicatorProps) => {
  // Calculate the progress percentage
  const progressPercentage = (currentStep / totalSteps) * 100

  // Get motivational phrase based on current step
  const getMotivationalPhrase = (step: number, total: number) => {
    switch (step) {
      case 1:
        return "📚 Start your book journey"
      case 2:
        return "✍️ Tell us about your content"
      case 3:
        return "🎭 Choose the voice of your story"
      case 4:
        return "🎯 Define tone and target audience"
      case 5:
        return "🎉 Preview your masterpiece"
      default:
        return `Step ${step} of ${total}`
    }
  }

  return (
    <div className="space-y-4 mb-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center text-sm text-gray-600 hover:text-gray-900">
          <span className="text-gray-600">
            Step {currentStep} of {totalSteps}
          </span>
        </div>
      </div>

      <Progress value={progressPercentage} className="h-2 bg-gray-200" />

      <div className="relative">
        <div className="flex justify-between items-center">
          {Array.from({ length: totalSteps }).map((_, index) => (
            <div
              key={index}
              className={`w-8 h-8 rounded-full flex items-center justify-center z-10 font-semibold text-sm ${
                index + 1 === currentStep
                  ? "bg-primary text-white"
                  : index + 1 < currentStep
                    ? "bg-primary/80 text-white"
                    : "bg-gray-200 text-gray-500"
              }`}
            >
              {index + 1}
            </div>
          ))}
        </div>
      </div>

      <div className="text-center text-gray-700 font-medium font-['Canela',_'Playfair_Display',_Georgia,_serif]">
        {getMotivationalPhrase(currentStep, totalSteps)}
      </div>
    </div>
  )
}

export default StepIndicator

