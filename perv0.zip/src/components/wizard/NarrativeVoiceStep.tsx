"use client"

import { useState } from "react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { InfoIcon, PlusCircle, Trash2 } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"

interface NarrativeVoiceStepProps {
  onUpdate: (data: {
    narrativeVoice: string
    tone: string
    bonusContent?: { title: string; description: string }[]
    contentDetails?: {
      recipeCount: number
      quizCount: number
      exerciseCount: number
      caseStudyCount: number
      chapterCount: number
    }
  }) => void
  onNext: () => void
  onBack: () => void
  bookData: {
    narrativeVoice: string
    tone: string
    niche: string
    bonusContent: { title: string; description: string }[]
    contentDetails: {
      recipeCount: number
      quizCount: number
      exerciseCount: number
      caseStudyCount: number
      chapterCount: number
    }
  }
}

const NarrativeVoiceStep = ({ onUpdate, onNext, onBack, bookData }: NarrativeVoiceStepProps) => {
  const isNextDisabled = !bookData.narrativeVoice || !bookData.tone
  const [newBonusTitle, setNewBonusTitle] = useState("")
  const [newBonusDescription, setNewBonusDescription] = useState("")

  const handleNarrativeVoiceChange = (value: string) => {
    onUpdate({
      narrativeVoice: value,
      tone: bookData.tone,
      bonusContent: bookData.bonusContent,
    })
  }

  const handleToneChange = (value: string) => {
    onUpdate({
      narrativeVoice: bookData.narrativeVoice,
      tone: value,
      bonusContent: bookData.bonusContent,
    })
  }

  const addBonusContent = () => {
    if (newBonusTitle.trim() !== "") {
      const updatedBonusContent = [
        ...bookData.bonusContent,
        {
          title: newBonusTitle.trim(),
          description: newBonusDescription.trim(),
        },
      ]
      onUpdate({
        narrativeVoice: bookData.narrativeVoice,
        tone: bookData.tone,
        bonusContent: updatedBonusContent,
      })
      setNewBonusTitle("")
      setNewBonusDescription("")
    }
  }

  const removeBonusContent = (index: number) => {
    const updatedBonusContent = [...bookData.bonusContent]
    updatedBonusContent.splice(index, 1)
    onUpdate({
      narrativeVoice: bookData.narrativeVoice,
      tone: bookData.tone,
      bonusContent: updatedBonusContent,
    })
  }

  const narrativeVoiceOptions = [
    {
      value: "firstPerson",
      label: "First Person",
      example: '"In this book, I\'ll help you master the art of cooking..."',
      recommendedFor: "coaching, self-help, personal stories, memoirs",
    },
    {
      value: "thirdPerson",
      label: "Third Person",
      example: '"This guide will help readers understand the fundamentals of..."',
      recommendedFor: "business, educational, technical content",
    },
  ]

  const toneOptions = [
    { value: "academic", label: "Accademico" },
    { value: "educational", label: "Educativo" },
    { value: "narrative", label: "Narrativo" },
    { value: "persuasive", label: "Persuasivo" },
    { value: "conversational", label: "Conversazionale" },
    { value: "professional", label: "Professionale" },
    { value: "humorous", label: "Umoristico" },
    { value: "inspirational", label: "Ispirazionale" },
  ]

  const getBonusSuggestions = () => {
    const suggestions: string[] = []
    const { niche, contentDetails } = bookData

    suggestions.push("Access to exclusive online resources")
    suggestions.push("Free digital workbook companion")

    if (niche?.includes("cook") || niche?.includes("food") || niche?.includes("recipe")) {
      suggestions.push("30-Day Meal Plan")
      suggestions.push("10 Exclusive Bonus Recipes")
      suggestions.push("Printable Shopping Lists")
      suggestions.push("Seasonal Menu Guides")
    } else if (niche?.includes("fitness") || niche?.includes("health") || niche?.includes("workout")) {
      suggestions.push("4-Week Workout Calendar")
      suggestions.push("Video Tutorials for Key Exercises")
      suggestions.push("Progress Tracker Templates")
    } else if (niche?.includes("business") || niche?.includes("entrepreneur") || niche?.includes("market")) {
      suggestions.push("10 Case Studies of Successful Businesses")
      suggestions.push("Business Plan Template")
      suggestions.push("ROI Calculator Spreadsheet")
    } else if (niche?.includes("self-help") || niche?.includes("personal") || niche?.includes("develop")) {
      suggestions.push("21-Day Challenge Guide")
      suggestions.push("Reflection Journal Template")
      suggestions.push("Daily Affirmations List")
    }

    if (contentDetails?.recipeCount && contentDetails.recipeCount > 0) {
      suggestions.push("Dietary Substitutions Guide")
      suggestions.push("Kitchen Equipment Checklist")
    }

    if (contentDetails?.quizCount && contentDetails.quizCount > 0) {
      suggestions.push("Additional Practice Questions")
      suggestions.push("Answer Key with Detailed Explanations")
    }

    if (contentDetails?.exerciseCount && contentDetails.exerciseCount > 0) {
      suggestions.push("Bonus Advanced Exercises")
      suggestions.push("Printable Exercise Log Sheets")
    }

    return suggestions.slice(0, 5)
  }

  const bonusSuggestions = getBonusSuggestions()

  const shouldShowBonusSection = () => {
    const { contentDetails } = bookData
    return (
      contentDetails.recipeCount > 0 ||
      contentDetails.quizCount > 0 ||
      contentDetails.exerciseCount > 0 ||
      contentDetails.caseStudyCount > 0 ||
      contentDetails.chapterCount > 0
    )
  }

  return (
    <div className="bg-white p-6 rounded-lg">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mt-4 mb-2">Voice and Tone Settings</h1>
        <p className="text-gray-600">Select how you want to address your readers and the tone of your book</p>
      </div>

      <div className="mb-8">
        <div className="flex items-center mb-4">
          <h2 className="text-xl font-semibold">Tone Selection</h2>
          <InfoIcon className="h-5 w-5 ml-2 text-gray-400" />
        </div>

        <div className="mb-6">
          <Label htmlFor="tone" className="block text-base mb-2">
            Tono del contenuto:
          </Label>
          <Select value={bookData.tone} onValueChange={handleToneChange}>
            <SelectTrigger id="tone" className="w-full bg-white">
              <SelectValue placeholder="Seleziona il tono di voce" />
            </SelectTrigger>
            <SelectContent className="bg-white">
              {toneOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="mb-8">
        <div className="flex items-center mb-4">
          <h2 className="text-xl font-semibold">Narrative Voice</h2>
          <InfoIcon className="h-5 w-5 ml-2 text-gray-400" />
        </div>

        <RadioGroup value={bookData.narrativeVoice} onValueChange={handleNarrativeVoiceChange} className="space-y-4">
          {narrativeVoiceOptions.map((option) => (
            <div
              key={option.value}
              className={`border rounded-lg p-5 ${bookData.narrativeVoice === option.value ? "border-orange-500 bg-orange-50" : "border-gray-200"}`}
              onClick={() => handleNarrativeVoiceChange(option.value)}
            >
              <div className="flex items-start">
                <RadioGroupItem value={option.value} id={option.value} className="mt-1" />
                <div className="ml-3 w-full cursor-pointer">
                  <Label htmlFor={option.value} className="text-lg font-medium cursor-pointer">
                    {option.label}
                  </Label>
                  <p className="text-gray-700 mt-2">{option.example}</p>
                  <p className="text-gray-500 text-sm mt-2">Recommended for: {option.recommendedFor}</p>
                </div>
              </div>
            </div>
          ))}
        </RadioGroup>
      </div>

      {shouldShowBonusSection() && (
        <div className="mb-8 border rounded-lg p-6 bg-orange-50">
          <div className="flex items-center mb-4">
            <h2 className="text-xl font-semibold">Bonus Content</h2>
            <InfoIcon className="h-5 w-5 ml-2 text-gray-400" />
          </div>

          <p className="text-gray-700 mb-4">
            Aggiungi altre informazioni per rendere il tuo libro migliore e differenziarlo dalla concorrenza.
          </p>

          {bookData.bonusContent.length > 0 && (
            <div className="mb-6 space-y-3">
              <h3 className="font-medium text-gray-800">Contenuti bonus aggiunti:</h3>
              {bookData.bonusContent.map((bonus, index) => (
                <div key={index} className="flex items-start gap-3 bg-white p-3 rounded-lg border border-gray-200">
                  <div className="flex-grow">
                    <h4 className="font-medium">{bonus.title}</h4>
                    {bonus.description && <p className="text-sm text-gray-600 mt-1">{bonus.description}</p>}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-gray-400 hover:text-red-500"
                    onClick={() => removeBonusContent(index)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          <div className="space-y-4 mb-6">
            <div>
              <Label htmlFor="bonus-title" className="block text-sm font-medium mb-1">
                Titolo del bonus
              </Label>
              <Input
                id="bonus-title"
                value={newBonusTitle}
                onChange={(e) => setNewBonusTitle(e.target.value)}
                placeholder="Es. 30-Day Meal Plan"
                className="w-full"
              />
            </div>

            <div>
              <Label htmlFor="bonus-description" className="block text-sm font-medium mb-1">
                Descrizione (opzionale)
              </Label>
              <Textarea
                id="bonus-description"
                value={newBonusDescription}
                onChange={(e) => setNewBonusDescription(e.target.value)}
                placeholder="Breve descrizione del contenuto bonus"
                className="w-full"
              />
            </div>

            <Button
              onClick={addBonusContent}
              disabled={!newBonusTitle.trim()}
              className="w-full bg-orange-500 hover:bg-orange-600 text-white"
            >
              <PlusCircle className="mr-2 h-4 w-4" /> Aggiungi Bonus
            </Button>
          </div>

          {bonusSuggestions.length > 0 && (
            <div className="mt-4">
              <h3 className="font-medium text-gray-800 mb-2">Suggerimenti per bonus:</h3>
              <div className="flex flex-wrap gap-2">
                {bonusSuggestions.map((suggestion, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="bg-white hover:bg-orange-100 border-orange-200 text-sm"
                    onClick={() => {
                      setNewBonusTitle(suggestion)
                      setNewBonusDescription("")
                    }}
                  >
                    {suggestion}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <div className="flex justify-between mt-10">
        <button
          onClick={onBack}
          className="flex items-center px-5 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
        >
          <span className="mr-2">←</span> Indietro
        </button>

        <button
          onClick={onNext}
          disabled={isNextDisabled}
          className="flex items-center px-5 py-2.5 bg-orange-500 hover:bg-orange-600 rounded-lg text-sm font-medium text-white shadow-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Continue <span className="ml-2">→</span>
        </button>
      </div>
    </div>
  )
}

export default NarrativeVoiceStep

