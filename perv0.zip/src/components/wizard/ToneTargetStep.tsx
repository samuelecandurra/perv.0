"use client"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ImageIcon, BookOpen, Sparkles, Info } from "lucide-react"
import { Slider } from "@/components/ui/slider"

interface ToneTargetStepProps {
  onUpdate: (data: {
    tone: string
    audience: string
    description: string
    uniqueSellingPoint: string
    includeImages: string
    imageCount: number
  }) => void
  onNext: () => void
  onBack: () => void
  bookData: {
    tone: string
    audience: string
    description: string
    uniqueSellingPoint: string
    includeImages: string
    imageCount: number
  }
}

const ToneTargetStep = ({ onUpdate, onNext, onBack, bookData }: ToneTargetStepProps) => {
  const isNextDisabled = !bookData.tone

  const handleChange = (field: string, value: string | number) => {
    onUpdate({
      ...bookData,
      [field]: value,
    })
  }

  const toneOptions = [
    { value: "academic", label: "Accademico" },
    { value: "educational", label: "Educativo" },
    { value: "narrative", label: "Narrativo" },
    { value: "persuasive", label: "Persuasivo" },
    { value: "conversational", label: "Conversazionale" },
    { value: "professional", label: "Professionale" },
    { value: "humorous", label: "Umoristico" },
    { value: "inspirational", label: "Ispirazionale" },
  ]

  const audienceOptions = [
    { value: "beginner", label: "Livello base" },
    { value: "intermediate", label: "Livello intermedio" },
    { value: "advanced", label: "Livello avanzato" },
    { value: "expert", label: "Esperti del settore" },
    { value: "general", label: "Pubblico generale" },
    { value: "professional", label: "Professionisti" },
    { value: "academic", label: "Accademico" },
  ]

  const imageOptions = [
    { value: "none", label: "No images" },
    { value: "photos", label: "Realistic photos" },
    { value: "illustrations", label: "Drawings/Illustrations" },
    { value: "diagrams", label: "Diagrams" },
  ]

  // Examples for description and unique selling point
  const descriptionExamples = [
    "Una guida completa per principianti sul trading di criptovalute",
    "Un manuale per imparare a cucinare piatti tradizionali italiani",
    "Storia e tecniche della fotografia moderna",
    "Metodologie di apprendimento per studiare le lingue straniere",
  ]

  const uniqueSellingPointExamples = [
    "Include 500 quiz per prepararti al concorso",
    "Con 30 ricette detox testate dallo chef",
    "Ogni capitolo termina con un esercizio pratico",
    "Contiene 10 casi studio di aziende di successo",
    "Interviste esclusive con 15 esperti del settore",
    "Book includes 5 Full-length Linear Digital SAT® Practice Tests",
    "150 Days Easy, Delicious & Nutritious Recipes Book for Balanced Eating",
    "30-Day Meal Plan to Get Started",
  ]

  return (
    <div className="space-y-8">
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mt-4 mb-2 font-['Canela',_'Playfair_Display',_Georgia,_serif]">
            Tono e Pubblico Target
          </h1>
        </div>

        <div className="space-y-8">
          <div className="mb-6">
            <Label htmlFor="tone" className="block text-base mb-2">
              Tono del contenuto:
            </Label>
            <Select value={bookData.tone} onValueChange={(value) => handleChange("tone", value)}>
              <SelectTrigger id="tone" className="w-full bg-white">
                <SelectValue placeholder="Seleziona il tono di voce" />
              </SelectTrigger>
              <SelectContent className="bg-white">
                {toneOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="mb-6">
            <Label htmlFor="audience" className="block text-base mb-2">
              Pubblico target:
            </Label>
            <Select value={bookData.audience} onValueChange={(value) => handleChange("audience", value)}>
              <SelectTrigger id="audience" className="w-full bg-white">
                <SelectValue placeholder="Seleziona il pubblico target" />
              </SelectTrigger>
              <SelectContent className="bg-white">
                {audienceOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="mt-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-orange-50 rounded-full flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-orange-500" />
              </div>
              <h2 className="text-2xl font-bold font-['Canela',_'Playfair_Display',_Georgia,_serif]">
                Descrizione del Contenuto
              </h2>
            </div>

            <div className="bg-orange-50 p-5 rounded-lg mb-6">
              <div className="flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-orange-500 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-orange-800 mb-1">Perché è importante?</h3>
                  <p className="text-orange-700 text-sm">
                    Una descrizione dettagliata aiuta a generare un libro più accurato e in linea con le tue
                    aspettative. Più dettagli inserisci, migliore sarà il risultato finale.
                  </p>
                </div>
              </div>
            </div>

            <div className="mb-8">
              <Label htmlFor="description" className="block text-base mb-2 font-semibold">
                Descrivi cosa vuoi che il tuo libro contenga:
              </Label>
              <Textarea
                id="description"
                value={bookData.description}
                onChange={(e) => handleChange("description", e.target.value)}
                placeholder="Descrivi gli argomenti principali, i problemi che risolve, ecc."
                className="min-h-[150px] bg-white"
              />

              <div className="mt-5 space-y-2">
                <div className="flex items-center gap-2 mb-1 text-blue-700">
                  <Info className="h-4 w-4" />
                  <p className="text-sm font-medium">Esempi di descrizioni efficaci:</p>
                </div>
                <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 space-y-3">
                  {descriptionExamples.map((example, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <div className="text-blue-500 mt-0.5">•</div>
                      <p className="text-sm text-blue-700">{example}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mb-6">
              <div className="flex items-start gap-3 mb-3">
                <Info className="w-5 h-5 text-blue-500 mt-1 flex-shrink-0" />
                <Label htmlFor="uniqueSellingPoint" className="block text-base font-semibold">
                  Cosa rende il tuo libro unico?
                </Label>
              </div>

              <Input
                id="uniqueSellingPoint"
                value={bookData.uniqueSellingPoint}
                onChange={(e) => handleChange("uniqueSellingPoint", e.target.value)}
                placeholder="Es. Include 500 quiz, 30 ricette detox, esercizi pratici..."
                className="bg-white mb-2"
              />

              <p className="text-sm text-gray-500 mb-3">
                Aggiungi elementi che differenziano il tuo libro dalla concorrenza e lo rendono più appetibile.
              </p>

              <div className="mt-4 bg-green-50 border border-green-100 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3 text-green-800">
                  <Sparkles className="h-4 w-4" />
                  <p className="text-sm font-semibold">Suggerimenti per rendere il tuo libro unico:</p>
                </div>
                <div className="space-y-3">
                  {uniqueSellingPointExamples.map((example, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <div className="text-green-600 mt-0.5">•</div>
                      <p className="text-sm text-green-700">{example}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Images Section */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center">
            <ImageIcon className="w-5 h-5 text-blue-500" />
          </div>
          <h2 className="text-2xl font-bold font-['Canela',_'Playfair_Display',_Georgia,_serif]">Images (Optional)</h2>
        </div>

        <div className="space-y-6">
          <div>
            <Label htmlFor="includeImages" className="block text-base mb-2">
              Include images in your ebook?
            </Label>
            <Select value={bookData.includeImages} onValueChange={(value) => handleChange("includeImages", value)}>
              <SelectTrigger id="includeImages" className="w-full bg-white border-orange-200 focus:ring-orange-500">
                <SelectValue placeholder="Select option" />
              </SelectTrigger>
              <SelectContent className="bg-white">
                {imageOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {bookData.includeImages && bookData.includeImages !== "none" && (
            <div className="space-y-4 p-4 bg-blue-50 rounded-md mt-2">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="imageCount" className="text-base font-medium">
                    Number of images:
                  </Label>
                  <span className="text-blue-700 font-semibold">{bookData.imageCount || 10}</span>
                </div>
                <Slider
                  id="imageCount"
                  min={5}
                  max={50}
                  step={5}
                  value={[bookData.imageCount || 10]}
                  onValueChange={(value) => handleChange("imageCount", value[0])}
                  className="bg-blue-100"
                />
                <div className="flex justify-between text-sm text-blue-700 mt-1">
                  <span>5</span>
                  <span>25</span>
                  <span>50</span>
                </div>
                <p className="text-sm text-blue-800 mt-2">Selecting more images will use more image credits.</p>
              </div>
            </div>
          )}

          <div className="flex items-center space-x-4 p-4 bg-blue-50 rounded-md">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
              <span className="text-blue-600 text-sm font-semibold">i</span>
            </div>
            <div>
              <p className="text-sm text-blue-800">Images will consume credits from your account.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-between mt-10">
        <button
          onClick={onBack}
          className="flex items-center px-5 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors font-['Inter',_'SF_Pro_Text',_-apple-system,_BlinkMacSystemFont,_'Segoe_UI',_Roboto,_'Helvetica_Neue',_Arial,_sans-serif]"
        >
          <span className="mr-2">←</span> Indietro
        </button>

        <button
          onClick={onNext}
          disabled={isNextDisabled}
          className="flex items-center px-5 py-2.5 bg-orange-500 hover:bg-orange-600 rounded-lg text-sm font-medium text-white shadow-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-['Inter',_'SF_Pro_Text',_-apple-system,_BlinkMacSystemFont,_'Segoe_UI',_Roboto,_'Helvetica_Neue',_Arial,_sans-serif]"
        >
          Continue <span className="ml-2">→</span>
        </button>
      </div>
    </div>
  )
}

export default ToneTargetStep

