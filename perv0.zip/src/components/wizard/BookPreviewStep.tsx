"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, ChevronRight, Star, Check, Edit, Book, ImageIcon } from "lucide-react"
import WizardButtons from "./WizardButtons"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import SignUpModal from "@/components/ui/SignUpModal"
import { toast } from "sonner"

interface BookPreviewStepProps {
  onUpdate: (data: { generatedPreview: string }) => void
  onNext: () => void
  onBack: () => void
  bookData: {
    title: string
    subtitle: string
    niche: string
    wordCount?: string
    bookStructure?: string[]
    generatedPreview: string
    includeImages: string
    imageCount: number
  }
}

const BookPreviewStep = ({ onUpdate, onNext, onBack, bookData }: BookPreviewStepProps) => {
  const [isGenerating, setIsGenerating] = useState(true)
  const [activeTab, setActiveTab] = useState("structure")
  const [isPurchaseDialogOpen, setIsPurchaseDialogOpen] = useState(false)

  const [previewContent, setPreviewContent] = useState("")
  const [limitedPreview, setLimitedPreview] = useState("")

  const userWordCount = Number.parseInt(bookData.wordCount || "0")
  const customWordCount = userWordCount > 0 ? userWordCount : 20000
  const customPrice = Math.max(Math.round(customWordCount * 0.006), 39)

  const imagePrice = bookData.includeImages !== "none" ? bookData.imageCount : 0
  const basePrice = 39
  const totalPrice = basePrice + imagePrice

  useEffect(() => {
    const timer = setTimeout(() => {
      const generatedContent = `# ${bookData.title}
${bookData.subtitle ? `## ${bookData.subtitle}` : ""}

## Introduzione e Presentazione

Benvenuti nella guida definitiva per la gestione dei social network! In questo libro, esploreremo le strategie, gli strumenti e le tecniche più efficaci per gestire con successo la tua presenza sui social media. Che tu sia un principiante assoluto o un marketer esperto, troverai informazioni preziose per migliorare la tua strategia sui social network.

### A chi è rivolto questo libro

Questo libro è stato scritto pensando a:
- Imprenditori e piccoli business che vogliono promuoversi online
- Social media manager alle prime armi
- Professionisti del marketing che vogliono ampliare le proprie competenze
- Chiunque desideri comprendere meglio il potenziale dei social network

### Come utilizzare questo libro

Ti consiglio di leggere il libro dall'inizio alla fine, ma ogni capitolo è stato progettato per essere autonomo. Puoi quindi consultare specifiche sezioni quando ne hai bisogno. Alla fine di ogni capitolo, troverai esercizi pratici e punti chiave da ricordare.

## Fondamenti del Social Media Marketing

Il social media marketing è diventato un elemento essenziale di qualsiasi strategia di marketing digitale. Ma cosa significa esattamente?

### Cos'è il Social Media Marketing?

Il social media marketing comprende tutte le attività svolte sui canali social per:
- Aumentare la visibilità del brand
- Incrementare il traffico verso il sito web
- Generare lead e conversioni
- Migliorare la comunicazione con i clienti
- Costruire una community attorno al proprio brand

### Perché i Social Media sono Importanti per il Business

In un mondo sempre più connesso, i social media offrono opportunità senza precedenti:

1. **Raggiungono un pubblico vasto**: Miliardi di persone utilizzano i social media ogni giorno.
2. **Targeting preciso**: Puoi raggiungere esattamente le persone interessate al tuo prodotto.
3. **Costi contenuti**: Rispetto ai media tradizionali, i social offrono un ROI potenzialmente più alto.
4. **Feedback immediato**: Puoi vedere in tempo reale come reagisce il tuo pubblico.
5. **Relazioni più strette**: Puoi interagire direttamente con i tuoi clienti.

### Le Piattaforme Social più Importanti

Ogni piattaforma ha caratteristiche uniche e attira diversi tipi di pubblico:

**Facebook**: Con oltre 2,8 miliardi di utenti attivi, rimane il social network più grande al mondo. È versatile e adatto a quasi tutti i tipi di business.

**Instagram**: Focalizzato sui contenuti visivi, è perfetto per brand con prodotti visivamente attraenti o storie da raccontare attraverso le immagini.

**LinkedIn**: La piattaforma professionale per eccellenza, ideale per B2B, networking professionale e personal branding.

**Twitter**: Perfetto per aggiornamenti rapidi, notizie e interazioni informali con i clienti.

**TikTok**: In rapida crescita, attira principalmente un pubblico giovane con contenuti video brevi e creativi.

**Pinterest**: Specializzato in contenuti visivi salvabili, è ideale per settori come moda, arredamento, ricette e fai-da-te.`

      setPreviewContent(generatedContent)

      const words = generatedContent.split(/\s+/)
      const limitedWords = words.slice(0, 400)
      setLimitedPreview(limitedWords.join(" ") + "...")

      onUpdate({ generatedPreview: generatedContent })
      setIsGenerating(false)
    }, 3000)

    return () => clearTimeout(timer)
  }, [])

  const handlePurchaseSingleBook = () => {
    console.log("Purchase single book")
    setIsPurchaseDialogOpen(false)
  }

  const handleOpenEditor = () => {
    onNext()
    toast.success("Editor aperto per il tuo libro")
  }

  return (
    <div className="space-y-10">
      <div className="text-center mb-4">
        <h2 className="text-3xl font-heading font-bold">Il tuo libro è pronto!</h2>
        <p className="text-muted-foreground mt-2 mb-2 font-body">Ecco l'anteprima del tuo libro generato con AI</p>
        <div className="text-amber-600 bg-amber-50 border border-amber-200 rounded-lg p-3 inline-flex items-center gap-2 text-sm font-body">
          <Star className="h-4 w-4" />
          <span>
            Anteprima limitata. Puoi modificare le prime 2000 parole gratuitamente. Acquista per accedere al libro
            completo.
          </span>
        </div>
      </div>

      {isGenerating ? (
        <Card className="p-10 flex flex-col items-center justify-center text-center bg-white">
          <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
          <h3 className="text-xl font-heading font-medium mb-2">Generazione del libro in corso...</h3>
          <p className="text-muted-foreground font-body">
            Stiamo creando la struttura e il contenuto del tuo libro in base alle tue specifiche. Questo processo
            potrebbe richiedere qualche istante.
          </p>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <Card className="p-6 flex flex-col items-center text-center col-span-1 bg-white">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <Book className="h-8 w-8 text-gray-600" />
              </div>
              <h3 className="text-lg font-heading font-medium mb-2">Una Tantum</h3>
              <p className="text-muted-foreground text-sm mb-4 font-body">
                Da 10.000 a 50.000+ parole con formattazione personalizzabile
              </p>

              {bookData.includeImages !== "none" && bookData.imageCount > 0 && (
                <div className="bg-blue-50 p-3 rounded-lg w-full mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium">Libro base:</span>
                    <span className="font-medium">€{basePrice}</span>
                  </div>
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center">
                      <ImageIcon className="h-3 w-3 mr-1 text-blue-600" />
                      <span className="text-sm font-medium">{bookData.imageCount} immagini:</span>
                    </div>
                    <span className="font-medium">€{imagePrice}</span>
                  </div>
                  <div className="border-t border-blue-200 mt-2 pt-2 flex justify-between items-center">
                    <span className="text-sm font-semibold">Totale:</span>
                    <span className="font-bold text-blue-700">€{totalPrice}</span>
                  </div>
                </div>
              )}

              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full font-body">
                    <span className="flex items-center">
                      Acquista €{totalPrice}
                      {bookData.includeImages !== "none" && (
                        <span className="ml-1 text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">
                          {bookData.imageCount} immagini incluse
                        </span>
                      )}
                    </span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md bg-white">
                  <SignUpModal />
                </DialogContent>
              </Dialog>
              <ul className="text-xs text-left mt-4 space-y-1 w-full font-body">
                <li className="flex items-center">
                  <Check className="h-3 w-3 text-green-600 mr-1" />
                  <span>Editor AI con rigenerazioni</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-3 w-3 text-green-600 mr-1" />
                  <span>Controllo anti-plagio</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-3 w-3 text-green-600 mr-1" />
                  <span>Pagamento singolo</span>
                </li>
                {bookData.includeImages !== "none" && (
                  <li className="flex items-center">
                    <Check className="h-3 w-3 text-green-600 mr-1" />
                    <span>{bookData.imageCount} immagini incluse</span>
                  </li>
                )}
              </ul>
            </Card>

            <Card className="p-6 border-2 border-blue-500 shadow-lg flex flex-col items-center text-center relative col-span-1 bg-white">
              <div className="absolute -top-3 px-4 py-1 bg-blue-600 text-white text-xs font-medium rounded-full font-body">
                Più popolare
              </div>
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <Star className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-heading font-medium mb-2">Pro</h3>
              <p className="text-muted-foreground text-sm mb-4 font-body">
                25.000 parole con funzionalità avanzate e formattazione
              </p>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700 font-body">Acquista €59</Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md bg-white">
                  <SignUpModal />
                </DialogContent>
              </Dialog>
              <ul className="text-xs text-left mt-4 space-y-1 w-full font-body">
                <li className="flex items-center">
                  <Check className="h-3 w-3 text-blue-600 mr-1" />
                  <span>Editor AI avanzato</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-3 w-3 text-blue-600 mr-1" />
                  <span>Controllo anti-plagio</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-3 w-3 text-blue-600 mr-1" />
                  <span>Da 10.000 a 50.000+ parole</span>
                </li>
              </ul>
            </Card>

            <Card className="p-6 flex flex-col items-center text-center col-span-1 bg-white">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <Check className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-heading font-medium mb-2">Premium</h3>
              <p className="text-muted-foreground text-sm mb-4 font-body">
                50.000 parole con assistenza completa e funzionalità premium
              </p>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full font-body">
                    Acquista €99
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md bg-white">
                  <SignUpModal />
                </DialogContent>
              </Dialog>
              <ul className="text-xs text-left mt-4 space-y-1 w-full font-body">
                <li className="flex items-center">
                  <Check className="h-3 w-3 text-green-600 mr-1" />
                  <span>Assistenza AI completa</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-3 w-3 text-green-600 mr-1" />
                  <span>Controllo anti-plagio</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-3 w-3 text-green-600 mr-1" />
                  <span>Da 10.000 a 50.000+ parole</span>
                </li>
              </ul>
            </Card>
          </div>

          <Button
            onClick={handleOpenEditor}
            className="w-full mb-6 bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 font-body"
          >
            <Edit className="h-4 w-4 mr-2" />
            Modifica il libro completo
          </Button>

          <Tabs defaultValue="structure" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-2 mb-6 bg-white">
              <TabsTrigger value="structure" className="font-body">
                Struttura Capitoli
              </TabsTrigger>
              <TabsTrigger value="preview" className="font-body">
                Anteprima Contenuto
              </TabsTrigger>
            </TabsList>

            <TabsContent value="structure" className="mt-0">
              <Card className="p-6 bg-white">
                <h3 className="text-xl font-heading font-bold mb-4">Struttura del libro</h3>
                <Accordion type="single" collapsible className="w-full">
                  {bookData.bookStructure?.map((chapter, index) => (
                    <AccordionItem key={index} value={`chapter-${index}`}>
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex items-center">
                          <span className="font-medium text-primary mr-2">{index + 1}.</span>
                          <span className="font-body">{chapter}</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="pl-8 pt-2 text-muted-foreground font-body">
                          <p>Questo capitolo sarà sviluppato completamente nel libro finale.</p>
                          <Button variant="link" size="sm" className="p-0 mt-1 h-auto text-blue-600 font-body">
                            <span>Anteprima completa</span>
                            <ChevronRight className="h-3 w-3 ml-1" />
                          </Button>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </Card>
            </TabsContent>

            <TabsContent value="preview" className="mt-0">
              <Card className="p-6 bg-white">
                <h3 className="text-xl font-heading font-bold mb-4">Anteprima limitata (primi capitoli)</h3>
                <div className="prose max-w-none">
                  <div className="whitespace-pre-wrap font-serif text-[15px]" style={{ whiteSpace: "pre-wrap" }}>
                    {limitedPreview.split("\n").map((line, i) => {
                      if (line.startsWith("# ")) {
                        return (
                          <h1 key={i} className="text-2xl font-heading font-bold mt-6 mb-4">
                            {line.substring(2)}
                          </h1>
                        )
                      } else if (line.startsWith("## ")) {
                        return (
                          <h2 key={i} className="text-xl font-heading font-bold mt-5 mb-3">
                            {line.substring(3)}
                          </h2>
                        )
                      } else if (line.startsWith("### ")) {
                        return (
                          <h3 key={i} className="text-lg font-heading font-bold mt-4 mb-2">
                            {line.substring(4)}
                          </h3>
                        )
                      } else if (line.startsWith("- ")) {
                        return (
                          <li key={i} className="ml-5 mb-1 font-body">
                            {line.substring(2)}
                          </li>
                        )
                      } else if (line.startsWith("**")) {
                        return (
                          <p key={i} className="font-bold mb-2 font-body">
                            {line.replace(/\*\*/g, "")}
                          </p>
                        )
                      } else if (line === "") {
                        return <br key={i} />
                      } else {
                        return (
                          <p key={i} className="mb-2 font-body">
                            {line}
                          </p>
                        )
                      }
                    })}
                  </div>

                  <div className="mt-6 border-t pt-4 flex flex-col items-center">
                    <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-lg mb-4 w-full">
                      <h4 className="font-heading font-medium mb-2 flex items-center">
                        <Star className="h-4 w-4 mr-2 text-amber-600" />
                        Contenuto completo disponibile dopo l'acquisto
                      </h4>
                      <p className="text-sm font-body">
                        Questa è solo un'anteprima limitata che puoi modificare gratuitamente. Acquista il libro
                        completo per accedere a tutti i capitoli e all'editor per personalizzarlo interamente.
                      </p>
                    </div>

                    <div className="flex flex-col md:flex-row gap-4 w-full">
                      <Button onClick={() => setIsPurchaseDialogOpen(true)} className="px-8 flex-1 font-body">
                        Sblocca contenuto completo
                      </Button>

                      <Button onClick={handleOpenEditor} variant="outline" className="px-8 flex-1 font-body">
                        <Edit className="h-4 w-4 mr-2" />
                        Modifica anteprima
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>
          </Tabs>

          <Dialog open={isPurchaseDialogOpen} onOpenChange={setIsPurchaseDialogOpen}>
            <DialogContent className="sm:max-w-md bg-white">
              <div className="p-4">
                <h2 className="text-2xl font-heading font-bold mb-4">Acquista "{bookData.title}"</h2>
                <p className="mb-4 font-body">Scegli un'opzione per accedere al libro completo e all'editor:</p>

                <div className="space-y-4 mb-6">
                  <div className="border p-4 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-white">
                    <div>
                      <h3 className="font-heading font-medium">Una Tantum</h3>
                      <p className="text-sm text-muted-foreground font-body">
                        Da 10.000 a 50.000+ parole con editor AI e controllo anti-plagio
                        {bookData.includeImages !== "none" && (
                          <span className="ml-1 text-blue-700">
                            + {bookData.imageCount} immagini (€{imagePrice})
                          </span>
                        )}
                      </p>
                    </div>
                    <Button variant="outline" className="font-body">
                      €{totalPrice}
                    </Button>
                  </div>

                  <div className="border-2 border-blue-500 p-4 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-white">
                    <div>
                      <h3 className="font-heading font-medium">Pro - 25.000 parole</h3>
                      <p className="text-sm text-muted-foreground font-body">Per ebook completi e manuali</p>
                    </div>
                    <Button className="bg-blue-600 hover:bg-blue-700 font-body">€59</Button>
                  </div>

                  <div className="border p-4 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-white">
                    <div>
                      <h3 className="font-heading font-medium">Premium - 50.000 parole</h3>
                      <p className="text-sm text-muted-foreground font-body">Per libri lunghi e contenuti complessi</p>
                    </div>
                    <Button variant="outline" className="font-body">
                      €99
                    </Button>
                  </div>

                  <div className="border p-4 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-white border-amber-200">
                    <div>
                      <h3 className="font-heading font-medium">
                        Personalizzato - {customWordCount.toLocaleString()} parole
                      </h3>
                      <p className="text-sm text-muted-foreground font-body">Su misura per le tue esigenze</p>
                    </div>
                    <Button
                      variant="outline"
                      className="border-amber-300 bg-amber-100 hover:bg-amber-200 text-amber-800 font-body"
                    >
                      €{customPrice}
                    </Button>
                  </div>
                </div>

                <div className="text-center text-sm text-muted-foreground font-body">
                  Per qualsiasi domanda contattaci all'email support@example.com
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </>
      )}

      <WizardButtons onNext={onNext} onBack={onBack} isLastStep={true} nextLabel="Completa" />
    </div>
  )
}

export default BookPreviewStep

