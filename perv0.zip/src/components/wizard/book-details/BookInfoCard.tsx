"use client"

import type React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { FileText, Info, HelpCircle } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { TooltipProvider, Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip"

interface BookInfoCardProps {
  title: string
  subtitle: string
  wordCount: string
  niche?: string
  onUpdate: (
    data: Partial<{
      title: string
      subtitle: string
      wordCount: string
      niche: string
    }>,
  ) => void
  handleChange: (e: React.ChangeEvent<HTMLInputElement>) => void
}

const BookInfoCard = ({ title, subtitle, wordCount, niche, onUpdate, handleChange }: BookInfoCardProps) => {
  const wordCountOptions = [
    { value: "10k-20k", label: "10.000 parole", description: "Ideale per eBook brevi e guide introduttive" },
    { value: "20k-35k", label: "25.000 parole", description: "Perfetto per manuali completi e guide pratiche" },
    {
      value: "35k-50k",
      label: "50.000+ parole",
      description: "Consigliato per contenuti approfonditi e libri formativi",
    },
  ]

  // Calculate pricing tier based on word count
  const getPricingInfo = () => {
    if (wordCount === "35k-50k" || wordCount === "80k+") {
      return {
        tier: "Premium",
        price: "€99",
        color: "#FF9900",
      }
    } else if (wordCount === "20k-35k") {
      return {
        tier: "Pro",
        price: "€59",
        color: "#FF9900",
      }
    } else {
      return {
        tier: "Una Tantum",
        price: "€39",
        color: "#FF9900",
      }
    }
  }

  const pricingInfo = getPricingInfo()

  return (
    <Card className="border-2 shadow-sm overflow-hidden transition-all duration-300 hover:shadow-md font-['Inter',_'SF_Pro_Text',_-apple-system,_BlinkMacSystemFont,_'Segoe_UI',_Roboto,_'Helvetica_Neue',_Arial,_sans-serif]">
      <div className="bg-[#F7F3EB] px-6 py-4 border-b-2">
        <div className="flex items-center">
          <h2 className="text-xl font-semibold text-[#333333]">Basic Information</h2>
        </div>
      </div>

      <CardContent className="p-6 space-y-6 bg-white">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-[#FF9900]" />
            <Label htmlFor="title" className="font-medium">
              Title:
            </Label>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <HelpCircle className="h-4 w-4 text-muted-foreground cursor-help" />
                </TooltipTrigger>
                <TooltipContent className="w-60">
                  <p>Make it catchy and relevant to your content</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <Input
            id="title"
            name="title"
            placeholder="Enter your book title"
            value={title}
            onChange={handleChange}
            className="border-2 focus-visible:ring-[#FF9900] bg-white"
          />
          <p className="text-sm text-muted-foreground">You can change this later. Make it catchy and relevant.</p>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Info className="h-5 w-5 text-[#FF9900]" />
            <Label htmlFor="subtitle" className="font-medium">
              Subtitle (Optional):
            </Label>
          </div>
          <Input
            id="subtitle"
            name="subtitle"
            placeholder="Enter a subtitle for your book"
            value={subtitle}
            onChange={handleChange}
            className="border-2 focus-visible:ring-[#FF9900] bg-white"
          />
          <p className="text-sm text-muted-foreground">Explain your value or promise.</p>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Label htmlFor="wordCount" className="font-medium">
              Word Count:
            </Label>
          </div>
          <Select value={wordCount} onValueChange={(value) => onUpdate({ wordCount: value })}>
            <SelectTrigger id="wordCount" className="w-full border-2 focus-visible:ring-[#FF9900] bg-white">
              <SelectValue placeholder="Select word count" />
            </SelectTrigger>
            <SelectContent>
              {wordCountOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                  <span className="text-xs block text-muted-foreground">{option.description}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {wordCount && (
            <div className="flex items-center gap-2 p-3 bg-[#FFF7EF] rounded-md mt-3 border border-[#FF9900]/30">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: pricingInfo.color }}></div>
              <p className="text-sm">
                This book size falls under the{" "}
                <span className="font-medium">
                  {pricingInfo.tier} Plan — {pricingInfo.price}
                </span>
                . You'll preview before paying.
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

export default BookInfoCard

