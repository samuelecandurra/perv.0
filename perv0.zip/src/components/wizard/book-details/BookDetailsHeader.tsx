const BookDetailsHeader = () => {
  return (
    <div className="text-center mb-10">
      <h1 className="text-3xl font-bold mb-3">📚 Create your masterpiece</h1>
      <p className="text-muted-foreground max-w-2xl mx-auto">
        Title, language, and topic - the building blocks of your next great book
      </p>
    </div>
  )
}

export default BookDetailsHeader

