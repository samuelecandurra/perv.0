"use client"

import { useState, useEffect } from "react"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BookOpen, Globe, FolderArchive, HelpCircle, Info } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import CookingNicheDetails from "../language-niche/CookingNicheDetails"

interface BookTypeCardProps {
  bookType: string
  language: string
  niche: string
  contentDetails: {
    recipeCount?: number
    quizCount?: number
    exerciseCount?: number
    caseStudyCount?: number
    chapterCount?: number
  }
  onUpdate: (
    data: Partial<{
      type: string
      language: string
      niche: string
      contentDetails: {
        recipeCount?: number
        quizCount?: number
        exerciseCount?: number
        caseStudyCount?: number
        chapterCount?: number
      }
    }>,
  ) => void
}

const BookTypeCard = ({ bookType, language, niche, contentDetails, onUpdate }: BookTypeCardProps) => {
  // Book type options
  const bookTypeOptions = [
    { value: "guide", label: "Guida" },
    { value: "manual", label: "Manuale" },
    { value: "diary", label: "Diario" },
    { value: "journal", label: "Journal" },
    { value: "fiction", label: "Fiction" },
    { value: "nonfiction", label: "Non-Fiction" },
    { value: "cookbook", label: "Ricettario" },
    { value: "memoir", label: "Memoir" },
  ]

  // Language options
  const languageOptions = [
    { value: "it", label: "Italiano" },
    { value: "en", label: "Inglese" },
    { value: "es", label: "Spagnolo" },
    { value: "fr", label: "Francese" },
    { value: "de", label: "Tedesco" },
  ]

  // Niche options
  const nicheOptions = [
    { value: "business", label: "Business" },
    { value: "selfhelp", label: "Self-Help" },
    { value: "education", label: "Educazione" },
    { value: "health", label: "Salute e Benessere" },
    { value: "technology", label: "Tecnologia" },
    { value: "finance", label: "Finanza" },
    { value: "marketing", label: "Marketing" },
    { value: "fiction", label: "Narrativa" },
    { value: "cookbook", label: "Cucina" },
    { value: "cucina", label: "Cucina" },
    { value: "howto", label: "Guide pratiche" },
    { value: "children", label: "Libri per bambini" },
  ]

  // State for recipe schema
  const [recipeSchema, setRecipeSchema] = useState("auto")
  const [customRecipeSchema, setCustomRecipeSchema] = useState("")
  const [recipeCount, setRecipeCount] = useState<number | "">(contentDetails.recipeCount || "")

  // Handle content detail changes
  const handleContentDetailChange = (key: string, value: number) => {
    onUpdate({
      contentDetails: {
        ...contentDetails,
        [key]: value,
      },
    })
  }

  // Helper function to check if the niche is cooking-related
  const isCookingNiche = () => {
    return niche === "cookbook" || niche === "cucina"
  }

  // Update recipeCount in contentDetails when local state changes
  useEffect(() => {
    if (typeof recipeCount === "number") {
      handleContentDetailChange("recipeCount", recipeCount)
    }
  }, [recipeCount])

  return (
    <div className="bg-[#F9F9F9] rounded-lg p-6 space-y-6 font-['Inter',_'SF_Pro_Text',_-apple-system,_BlinkMacSystemFont,_'Segoe_UI',_Roboto,_'Helvetica_Neue',_Arial,_sans-serif]">
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-[#FF9900]" />
          <Label htmlFor="type" className="font-medium text-gray-800">
            Book Type:
          </Label>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <HelpCircle className="h-4 w-4 text-gray-400 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="w-56">
                <p>Choose the format that best suits your content and goals</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <Select value={bookType} onValueChange={(value) => onUpdate({ type: value })}>
          <SelectTrigger id="type" className="w-full bg-white">
            <SelectValue placeholder="Select book type" />
          </SelectTrigger>
          <SelectContent>
            {bookTypeOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <Globe className="h-5 w-5 text-[#FF9900]" />
          <Label htmlFor="language" className="font-medium text-gray-800">
            Language:
          </Label>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <HelpCircle className="h-4 w-4 text-gray-400 cursor-help" />
              </TooltipTrigger>
              <TooltipContent>
                <p>Select the language your book will be written in</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <Select value={language} onValueChange={(value) => onUpdate({ language: value })}>
          <SelectTrigger id="language" className="w-full bg-white">
            <SelectValue placeholder="Select language" />
          </SelectTrigger>
          <SelectContent>
            {languageOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <FolderArchive className="h-5 w-5 text-[#FF9900]" />
          <Label htmlFor="niche" className="font-medium text-gray-800">
            Category/Niche:
          </Label>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <HelpCircle className="h-4 w-4 text-gray-400 cursor-help" />
              </TooltipTrigger>
              <TooltipContent>
                <p>Categorize your book to help with AI generation and marketing</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <Select value={niche} onValueChange={(value) => onUpdate({ niche: value })}>
          <SelectTrigger id="niche" className="w-full bg-white">
            <SelectValue placeholder="Select category/niche" />
          </SelectTrigger>
          <SelectContent>
            {nicheOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Specialized content details based on niche */}
      {niche && (
        <div className="p-4 bg-blue-50 border border-blue-100 rounded-lg space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Info className="h-5 w-5 text-blue-600" />
            <h3 className="font-medium text-blue-800">Dettagli del contenuto</h3>
          </div>

          <p className="text-sm text-blue-700 font-medium">
            Questa parte è determinante per il contenuto del tuo libro.
          </p>

          {isCookingNiche() && (
            <CookingNicheDetails
              recipeCount={recipeCount}
              setRecipeCount={setRecipeCount}
              recipeSchema={recipeSchema}
              setRecipeSchema={setRecipeSchema}
              customRecipeSchema={customRecipeSchema}
              setCustomRecipeSchema={setCustomRecipeSchema}
            />
          )}

          {niche === "education" && (
            <div className="space-y-2">
              <Label htmlFor="quizCount" className="text-sm text-blue-800">
                Quanti quiz o test vuoi includere?
              </Label>
              <Input
                id="quizCount"
                type="number"
                className="bg-white border-blue-200"
                value={contentDetails.quizCount || ""}
                min={0}
                onChange={(e) => handleContentDetailChange("quizCount", Number.parseInt(e.target.value) || 0)}
                placeholder="Es. 10"
              />
              <p className="text-xs text-blue-600">
                I quiz aiutano a rafforzare l'apprendimento e valutare la comprensione
              </p>
            </div>
          )}

          {niche === "selfhelp" && (
            <div className="space-y-2">
              <Label htmlFor="exerciseCount" className="text-sm text-blue-800">
                Quanti esercizi pratici vuoi includere?
              </Label>
              <Input
                id="exerciseCount"
                type="number"
                className="bg-white border-blue-200"
                value={contentDetails.exerciseCount || ""}
                min={0}
                onChange={(e) => handleContentDetailChange("exerciseCount", Number.parseInt(e.target.value) || 0)}
                placeholder="Es. 15"
              />
              <p className="text-xs text-blue-600">Gli esercizi pratici rendono il libro più interattivo e utile</p>
            </div>
          )}

          {niche === "business" && (
            <div className="space-y-2">
              <Label htmlFor="caseStudyCount" className="text-sm text-blue-800">
                Quanti casi studio vuoi includere?
              </Label>
              <Input
                id="caseStudyCount"
                type="number"
                className="bg-white border-blue-200"
                value={contentDetails.caseStudyCount || ""}
                min={0}
                onChange={(e) => handleContentDetailChange("caseStudyCount", Number.parseInt(e.target.value) || 0)}
                placeholder="Es. 5"
              />
              <p className="text-xs text-blue-600">
                I casi studio offrono esempi reali che illustrano i concetti del libro
              </p>
            </div>
          )}

          {(niche === "fiction" || niche === "nonfiction") && (
            <div className="space-y-2">
              <Label htmlFor="chapterCount" className="text-sm text-blue-800">
                Quanti capitoli vuoi che abbia il libro?
              </Label>
              <Input
                id="chapterCount"
                type="number"
                className="bg-white border-blue-200"
                value={contentDetails.chapterCount || ""}
                min={1}
                onChange={(e) => handleContentDetailChange("chapterCount", Number.parseInt(e.target.value) || 0)}
                placeholder="Es. 12"
              />
              <p className="text-xs text-blue-600">
                La struttura a capitoli aiuta a organizzare il contenuto in modo più chiaro
              </p>
            </div>
          )}

          {(niche === "howto" || niche === "technology") && (
            <div className="space-y-2">
              <Label htmlFor="exerciseCount" className="text-sm text-blue-800">
                Quanti esempi o progetti pratici vuoi includere?
              </Label>
              <Input
                id="exerciseCount"
                type="number"
                className="bg-white border-blue-200"
                value={contentDetails.exerciseCount || ""}
                min={0}
                onChange={(e) => handleContentDetailChange("exerciseCount", Number.parseInt(e.target.value) || 0)}
                placeholder="Es. 8"
              />
              <p className="text-xs text-blue-600">
                Gli esempi pratici aiutano i lettori a mettere in pratica le conoscenze acquisite
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default BookTypeCard

