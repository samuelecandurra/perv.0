"use client"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { BookOpen } from "lucide-react"

interface BookPreviewCardProps {
  bookData: {
    type: string
    language: string
    niche: string
    title: string
    subtitle: string
    wordCount: string
  }
  onReturn: () => void
}

const BookPreviewCard = ({ bookData, onReturn }: BookPreviewCardProps) => {
  // Book type options
  const bookTypeOptions = [
    { value: "guide", label: "Guida" },
    { value: "manual", label: "Manuale" },
    { value: "diary", label: "Diario" },
    { value: "journal", label: "Journal" },
    { value: "fiction", label: "Fiction" },
    { value: "nonfiction", label: "Non-Fiction" },
    { value: "cookbook", label: "Ricettario" },
    { value: "memoir", label: "Memoir" },
  ]

  // Language options
  const languageOptions = [
    { value: "it", label: "Italiano" },
    { value: "en", label: "Inglese" },
    { value: "es", label: "Spagnolo" },
    { value: "fr", label: "Francese" },
    { value: "de", label: "Tedesco" },
  ]

  // Niche options
  const nicheOptions = [
    { value: "business", label: "Business" },
    { value: "selfhelp", label: "Self-Help" },
    { value: "education", label: "Educazione" },
    { value: "health", label: "Salute e Benessere" },
    { value: "technology", label: "Tecnologia" },
    { value: "finance", label: "Finanza" },
    { value: "marketing", label: "Marketing" },
    { value: "fiction", label: "Narrativa" },
    { value: "cookbook", label: "Cucina" },
    { value: "howto", label: "Guide pratiche" },
    { value: "children", label: "Libri per bambini" },
  ]

  // Word count options
  const wordCountOptions = [
    { value: "10k-20k", label: "10.000 parole", description: "Ideale per eBook brevi e guide introduttive" },
    { value: "20k-35k", label: "25.000 parole", description: "Perfetto per manuali completi e guide pratiche" },
    {
      value: "35k-50k",
      label: "50.000+ parole",
      description: "Consigliato per contenuti approfonditi e libri formativi",
    },
  ]

  return (
    <Card className="border-2 shadow-sm p-6">
      <div className="flex justify-between items-start">
        <div className="space-y-4 max-w-md">
          <div className="space-y-1">
            <h3 className="text-sm font-medium text-muted-foreground">Book Type</h3>
            <p className="text-lg font-medium">
              {bookData.type ? bookTypeOptions.find((o) => o.value === bookData.type)?.label : "Not selected"}
            </p>
          </div>

          <div className="space-y-1">
            <h3 className="text-sm font-medium text-muted-foreground">Language</h3>
            <p className="text-lg font-medium">
              {bookData.language ? languageOptions.find((o) => o.value === bookData.language)?.label : "Not selected"}
            </p>
          </div>

          <div className="space-y-1">
            <h3 className="text-sm font-medium text-muted-foreground">Category/Niche</h3>
            <p className="text-lg font-medium">
              {bookData.niche ? nicheOptions.find((o) => o.value === bookData.niche)?.label : "Not selected"}
            </p>
          </div>

          <div className="border-t pt-4 mt-4">
            <h3 className="text-lg font-bold">{bookData.title || "Your Book Title"}</h3>
            {bookData.subtitle && <p className="text-md italic">{bookData.subtitle}</p>}
          </div>

          <div className="space-y-1">
            <h3 className="text-sm font-medium text-muted-foreground">Length</h3>
            <p className="text-lg font-medium">
              {bookData.wordCount
                ? wordCountOptions.find((o) => o.value === bookData.wordCount)?.label
                : "Not selected"}
            </p>
          </div>
        </div>

        <div className="hidden md:block w-48 h-64 bg-[#F7F3EB] rounded-md shadow-md relative border-2 border-gray-200">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center p-4">
              <BookOpen size={36} className="mx-auto mb-2 text-[#FF9900]" />
              {bookData.title ? (
                <>
                  <h3 className="font-bold text-sm leading-tight mb-1">{bookData.title}</h3>
                  {bookData.subtitle && <p className="text-xs italic">{bookData.subtitle}</p>}
                </>
              ) : (
                <p className="text-sm text-muted-foreground">Book Preview</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {Object.values(bookData).some(Boolean) && (
        <Button variant="outline" onClick={onReturn} className="mt-4 text-sm">
          Return to form to complete
        </Button>
      )}
    </Card>
  )
}

export default BookPreviewCard

