"use client"

import type React from "react"
import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import WizardButtons from "./WizardButtons"
import { InfoIcon, PlusCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

interface BookInfoStepProps {
  onUpdate: (data: {
    title: string
    subtitle: string
    wordCount: string
    uniqueSellingPoint?: string
    niche?: string
    bonusContent?: { title: string; description: string }[]
  }) => void
  onNext: () => void
  onBack: () => void
  bookData: {
    title: string
    subtitle: string
    wordCount: string
    uniqueSellingPoint?: string
    niche?: string
    bonusContent?: { title: string; description: string }[]
  }
}

const BookInfoStep = ({ onUpdate, onNext, onBack, bookData }: BookInfoStepProps) => {
  const isNextDisabled = !bookData.title || !bookData.wordCount
  const [newBonusTitle, setNewBonusTitle] = useState("")
  const [newBonusDescription, setNewBonusDescription] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    onUpdate({
      ...bookData,
      [name]: value,
    })
  }

  const handleWordCountChange = (value: string) => {
    onUpdate({
      ...bookData,
      wordCount: value,
    })
  }

  const addBonusContent = () => {
    if (newBonusTitle.trim() !== "") {
      const updatedBonusContent = [
        ...(bookData.bonusContent || []),
        {
          title: newBonusTitle.trim(),
          description: newBonusDescription.trim(),
        },
      ]
      onUpdate({
        ...bookData,
        bonusContent: updatedBonusContent,
      })
      setNewBonusTitle("")
      setNewBonusDescription("")
    }
  }

  const removeBonusContent = (index: number) => {
    const updatedBonusContent = [...(bookData.bonusContent || [])]
    updatedBonusContent.splice(index, 1)
    onUpdate({
      ...bookData,
      bonusContent: updatedBonusContent,
    })
  }

  const getBonusSuggestions = () => {
    const suggestions: string[] = []

    suggestions.push("Access to exclusive online resources")
    suggestions.push("Free digital workbook companion")

    if (bookData.niche?.includes("cookbook")) {
      suggestions.push("30-Day Meal Plan")
      suggestions.push("10 Exclusive Bonus Recipes")
      suggestions.push("Printable Shopping Lists")
    } else if (bookData.niche?.includes("business")) {
      suggestions.push("10 Case Studies of Successful Businesses")
      suggestions.push("Business Plan Template")
      suggestions.push("ROI Calculator Spreadsheet")
    } else if (bookData.niche?.includes("selfhelp")) {
      suggestions.push("21-Day Challenge Guide")
      suggestions.push("Reflection Journal Template")
      suggestions.push("Daily Affirmations List")
    } else if (bookData.niche?.includes("education")) {
      suggestions.push("Additional Practice Questions")
      suggestions.push("Study Guide Checklist")
    }

    return suggestions.slice(0, 5)
  }

  const bonusSuggestions = getBonusSuggestions()

  const wordCountOptions = [
    { value: "5k-10k", label: "5.000 - 10.000 parole" },
    { value: "10k-20k", label: "10.000 - 20.000 parole" },
    { value: "20k-35k", label: "20.000 - 35.000 parole" },
    { value: "35k-50k", label: "35.000 - 50.000 parole" },
    { value: "50k-80k", label: "50.000 - 80.000 parole" },
    { value: "80k+", label: "Più di 80.000 parole" },
  ]

  return (
    <div className="space-y-10 font-['Inter',_'SF_Pro_Text',_-apple-system,_BlinkMacSystemFont,_'Segoe_UI',_Roboto,_'Helvetica_Neue',_Arial,_sans-serif]">
      <div className="p-6 bg-[#FFF7EF] rounded-lg border border-[#FFDAB5]">
        <div className="flex items-center mb-4">
          <h2 className="text-2xl font-bold">Bonus Content</h2>
          <InfoIcon className="h-5 w-5 ml-2 text-gray-400" />
        </div>

        <p className="text-gray-700 mb-6">
          Aggiungi altre informazioni per rendere il tuo libro migliore e differenziarlo dalla concorrenza.
        </p>

        {bookData.bonusContent && bookData.bonusContent.length > 0 && (
          <div className="mb-6 space-y-3">
            <h3 className="font-medium text-gray-800">Contenuti bonus aggiunti:</h3>
            {bookData.bonusContent.map((bonus, index) => (
              <div key={index} className="flex items-start gap-3 bg-white p-3 rounded-lg border border-gray-200">
                <div className="flex-grow">
                  <h4 className="font-medium">{bonus.title}</h4>
                  {bonus.description && <p className="text-sm text-gray-600 mt-1">{bonus.description}</p>}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-gray-400 hover:text-red-500"
                  onClick={() => removeBonusContent(index)}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <path d="M3 6h18"></path>
                    <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                    <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                    <line x1="10" x2="10" y1="11" y2="17"></line>
                    <line x1="14" x2="14" y1="11" y2="17"></line>
                  </svg>
                </Button>
              </div>
            ))}
          </div>
        )}

        <div className="space-y-4 mb-6">
          <div>
            <Label htmlFor="bonus-title" className="block text-sm font-medium mb-1">
              Titolo del bonus
            </Label>
            <Input
              id="bonus-title"
              value={newBonusTitle}
              onChange={(e) => setNewBonusTitle(e.target.value)}
              placeholder="Es. 30-Day Meal Plan"
              className="w-full"
            />
          </div>

          <div>
            <Label htmlFor="bonus-description" className="block text-sm font-medium mb-1">
              Descrizione (opzionale)
            </Label>
            <Textarea
              id="bonus-description"
              value={newBonusDescription}
              onChange={(e) => setNewBonusDescription(e.target.value)}
              placeholder="Breve descrizione del contenuto bonus"
              className="w-full"
            />
          </div>

          <Button
            onClick={addBonusContent}
            disabled={!newBonusTitle.trim()}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white"
          >
            <PlusCircle className="mr-2 h-4 w-4" /> Aggiungi Bonus
          </Button>
        </div>

        {bonusSuggestions.length > 0 && (
          <div className="mt-4">
            <h3 className="font-medium text-gray-800 mb-2">Suggerimenti per bonus:</h3>
            <div className="flex flex-wrap gap-2">
              {bonusSuggestions.map((suggestion, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="bg-white hover:bg-orange-100 border-orange-200 text-sm"
                  onClick={() => {
                    setNewBonusTitle(suggestion)
                    setNewBonusDescription("")
                  }}
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-white">
        <h2 className="text-2xl font-bold mb-6">Basic Information</h2>

        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="niche">Book Niche/Category:</Label>
            <Select value={bookData.niche || ""} onValueChange={(value) => onUpdate({ ...bookData, niche: value })}>
              <SelectTrigger id="niche" className="w-full">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="education">Education</SelectItem>
                <SelectItem value="business">Business</SelectItem>
                <SelectItem value="selfhelp">Self-Help</SelectItem>
                <SelectItem value="fiction">Fiction</SelectItem>
                <SelectItem value="cookbook">Cookbook</SelectItem>
                <SelectItem value="howto">How-To</SelectItem>
                <SelectItem value="children">Children's Books</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Book Title:</Label>
            <Input
              id="title"
              name="title"
              placeholder="Enter your book title"
              value={bookData.title}
              onChange={handleChange}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="subtitle">Subtitle (Optional):</Label>
            <Input
              id="subtitle"
              name="subtitle"
              placeholder="Enter a subtitle for your book"
              value={bookData.subtitle}
              onChange={handleChange}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="wordCount">Length:</Label>
            <Select value={bookData.wordCount} onValueChange={handleWordCountChange}>
              <SelectTrigger id="wordCount" className="w-full">
                <SelectValue placeholder="Select word count" />
              </SelectTrigger>
              <SelectContent>
                {wordCountOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="p-6 bg-white">
        <h2 className="text-2xl font-bold mb-6">Unique Selling Proposition (USP) / Bonus</h2>

        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="uniqueSellingPoint">What makes your book unique?</Label>
            <Textarea
              id="uniqueSellingPoint"
              name="uniqueSellingPoint"
              rows={4}
              placeholder="Describe what makes your book stand out"
              value={bookData.uniqueSellingPoint || ""}
              onChange={handleChange}
            />
            <p className="text-sm text-muted-foreground mt-2">
              E.g., "Includes 30-day meal plan", "Contains interactive quizzes", etc.
            </p>
          </div>

          <div className="p-4 bg-[#FFF7EF] rounded-lg mt-4">
            <h3 className="font-semibold text-base mb-2">Tips per un libro di successo:</h3>
            <ul className="space-y-2 text-sm">
              <li>
                • <span className="font-medium">Offri materiali bonus:</span> Template, checklist, o guide supplementari
                aumentano il valore percepito.
              </li>
              <li>
                • <span className="font-medium">Rendi il libro interattivo:</span> Esercizi pratici, quiz o sfide
                coinvolgono maggiormente il lettore.
              </li>
              <li>
                • <span className="font-medium">Includi testimonianze:</span> Case study reali e storie di successo
                aumentano la credibilità.
              </li>
              <li>
                • <span className="font-medium">Aggiorna regolarmente:</span> Prometti aggiornamenti gratuiti dei
                contenuti nelle future edizioni.
              </li>
              <li>
                • <span className="font-medium">Offri risorse digitali:</span> Accesso a una community esclusiva, corsi
                online o webinar di supporto.
              </li>
            </ul>
          </div>
        </div>
      </div>

      <WizardButtons onNext={onNext} onBack={onBack} isNextDisabled={isNextDisabled} />
    </div>
  )
}

export default BookInfoStep

