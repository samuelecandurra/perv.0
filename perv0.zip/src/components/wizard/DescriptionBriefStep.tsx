"use client"

import { useState } from "react"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Sparkles, RotateCw, BookOpen, Plus, Trash2 } from "lucide-react"
import WizardButtons from "./WizardButtons"

interface DescriptionBriefStepProps {
  onUpdate: (
    data: Partial<{
      generatedBrief: string
      chapterStructure: {
        title: string
        content: string
      }[]
    }>,
  ) => void
  onNext: () => void
  onBack: () => void
  bookData: {
    type: string
    language: string
    niche: string
    title: string
    subtitle: string
    wordCount: string
    generatedBrief: string
    contentDetails: {
      recipeCount?: number
      quizCount?: number
      exerciseCount?: number
      caseStudyCount?: number
      chapterCount?: number
    }
    chapterStructure: {
      title: string
      content: string
    }[]
    bonusContent?: {
      title: string
      description: string
    }[]
  }
}

const DescriptionBriefStep = ({ onUpdate, onNext, onBack, bookData }: DescriptionBriefStepProps) => {
  const [isGenerating, setIsGenerating] = useState(false)

  const handleGenerateBrief = () => {
    setIsGenerating(true)

    // Simulate API call for brief generation
    setTimeout(() => {
      const contentTypeText = getContentTypeText()
      const generatedBrief = `This ${bookData.wordCount}-word ${bookData.niche} ${bookData.type.toLowerCase()} titled "${bookData.title}" ${bookData.subtitle ? `with subtitle "${bookData.subtitle}"` : ""} will ${contentTypeText}. It's designed for readers interested in ${bookData.niche.toLowerCase()}.`

      // Generate sample chapter structure based on book type and niche
      const chapterCount = bookData.contentDetails.chapterCount || 5
      const chapterStructure = generateSampleChapters(chapterCount)

      onUpdate({
        generatedBrief: generatedBrief,
        chapterStructure: chapterStructure,
      })

      setIsGenerating(false)
    }, 1500)
  }

  const getContentTypeText = () => {
    switch (bookData.niche.toLowerCase()) {
      case "cookbook":
        return `feature ${bookData.contentDetails.recipeCount || 10} unique recipes`
      case "self-help":
        return `provide practical exercises and actionable advice`
      case "education":
        return `include ${bookData.contentDetails.quizCount || 5} quizzes and educational content`
      case "business":
        return `present ${bookData.contentDetails.caseStudyCount || 3} case studies and business strategies`
      default:
        return `cover comprehensive information about ${bookData.niche.toLowerCase()}`
    }
  }

  const generateSampleChapters = (count: number) => {
    const chapters = []

    for (let i = 1; i <= count; i++) {
      let title = ""
      let content = ""

      switch (bookData.niche.toLowerCase()) {
        case "cookbook":
          title =
            i === 1
              ? "Introduction to Cooking"
              : `Chapter ${i}: ${["Appetizers", "Main Courses", "Desserts", "Beverages", "Special Occasions"][i % 5]}`
          content = `This chapter will contain ${Math.floor(bookData.contentDetails.recipeCount / count)} recipes focused on ${title.split(": ")[1] || "cooking basics"}.`
          break
        case "self-help":
          title =
            i === 1
              ? "Understanding Your Potential"
              : `Chapter ${i}: ${["Setting Goals", "Building Habits", "Overcoming Obstacles", "Maintaining Motivation", "Future Growth"][i % 5]}`
          content = `This chapter explores the concept of ${title.split(": ")[1] || "self-improvement"} with practical exercises and reflections.`
          break
        default:
          title = `Chapter ${i}: ${bookData.niche} Fundamentals ${i}`
          content = `This chapter covers key aspects of ${bookData.niche.toLowerCase()} with detailed explanations and examples.`
      }

      chapters.push({ title, content })
    }

    return chapters
  }

  const handleChapterUpdate = (index: number, field: "title" | "content", value: string) => {
    const updatedChapters = [...bookData.chapterStructure]
    updatedChapters[index] = {
      ...updatedChapters[index],
      [field]: value,
    }

    onUpdate({ chapterStructure: updatedChapters })
  }

  const handleAddChapter = () => {
    const newChapter = {
      title: `Chapter ${bookData.chapterStructure.length + 1}`,
      content: "Write your chapter content here...",
    }
    onUpdate({
      chapterStructure: [...bookData.chapterStructure, newChapter],
    })
  }

  const handleRemoveChapter = (index: number) => {
    const updatedChapters = [...bookData.chapterStructure]
    updatedChapters.splice(index, 1)
    onUpdate({ chapterStructure: updatedChapters })
  }

  const isNextDisabled = !bookData.generatedBrief || bookData.chapterStructure.length === 0

  return (
    <div className="space-y-8 font-['Inter',_'SF_Pro_Text',_-apple-system,_BlinkMacSystemFont,_'Segoe_UI',_Roboto,_'Helvetica_Neue',_Arial,_sans-serif]">
      <div className="text-center space-y-2 max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900">Book Structure & Content</h1>
        <p className="text-gray-600">Create a detailed brief and chapter structure for your book</p>
      </div>

      <div className="max-w-3xl mx-auto space-y-8">
        {/* Generated Brief Section */}
        <div className="relative border border-gray-100 rounded-lg bg-white p-6 shadow-sm">
          <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#FF9900] rounded-l-lg"></div>

          <div className="pl-4 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">Generated Brief:</h2>
              <Button
                onClick={handleGenerateBrief}
                variant="outline"
                size="sm"
                className="flex items-center text-gray-700 gap-2"
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <>
                    <RotateCw className="h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 text-[#FF9900]" />
                    {bookData.generatedBrief ? "Regenerate Brief" : "Generate Brief"}
                  </>
                )}
              </Button>
            </div>

            <Textarea
              id="generatedBrief"
              placeholder="Your generated brief will appear here..."
              value={bookData.generatedBrief}
              onChange={(e) => onUpdate({ generatedBrief: e.target.value })}
              className="min-h-[150px] resize-y bg-white border-gray-200 focus:border-[#FF9900] focus:ring-[#FF9900]"
            />

            <p className="text-sm text-gray-500">
              This brief is generated based on your book details. Feel free to edit it to better match your vision.
            </p>
          </div>
        </div>

        {/* Chapter Structure Section */}
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Chapter Structure</h2>
            <Button
              onClick={bookData.chapterStructure.length === 0 ? handleGenerateBrief : handleAddChapter}
              variant="outline"
              size="sm"
              className="flex items-center text-gray-700 gap-2"
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  <RotateCw className="h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : bookData.chapterStructure.length === 0 ? (
                <>
                  <BookOpen className="h-4 w-4 text-[#0EA5E9]" />
                  Generate Chapters
                </>
              ) : (
                <>
                  <Plus className="h-4 w-4 text-[#0EA5E9]" />
                  Add Chapter
                </>
              )}
            </Button>
          </div>

          {bookData.chapterStructure.length > 0 ? (
            <div className="space-y-4">
              {bookData.chapterStructure.map((chapter, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-3">
                    <label className="block text-sm font-medium text-gray-700">Chapter {index + 1}</label>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveChapter(index)}
                      className="h-8 w-8 p-0 text-gray-500 hover:text-red-500"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="mb-3">
                    <input
                      type="text"
                      value={chapter.title}
                      onChange={(e) => handleChapterUpdate(index, "title", e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[#0EA5E9] focus:border-[#0EA5E9]"
                      placeholder="Chapter title"
                    />
                  </div>
                  <div>
                    <Textarea
                      value={chapter.content}
                      onChange={(e) => handleChapterUpdate(index, "content", e.target.value)}
                      className="min-h-[100px] resize-y"
                      placeholder="Chapter content summary..."
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 border border-dashed border-gray-300 rounded-lg">
              <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-500">
                No chapters defined yet. Click "Generate Chapters" to create a chapter structure.
              </p>
            </div>
          )}
        </div>
      </div>

      <WizardButtons
        onNext={onNext}
        onBack={onBack}
        nextLabel="Continue"
        backLabel="Back"
        isNextDisabled={isNextDisabled}
      />
    </div>
  )
}

export default DescriptionBriefStep

