"use client"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import WizardButtons from "./WizardButtons"

interface BookFormatStepProps {
  onUpdate: (
    data: Partial<{
      includeQuizzes: string
      graphicTemplate: string
      colorScheme: string
      includeImages: string
      imageCount: number
    }>,
  ) => void
  onNext: () => void
  onBack: () => void
  bookData: {
    includeQuizzes: string
    graphicTemplate: string
    colorScheme: string
    includeImages: string
    imageCount: number
  }
}

const BookFormatStep = ({ onUpdate, onNext, onBack, bookData }: BookFormatStepProps) => {
  return (
    <div className="space-y-10">
      <div className="p-6 bg-white">
        <h2 className="text-2xl font-bold mb-6">Quizzes (Optional)</h2>

        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="includeQuizzes">Include quizzes in your ebook?</Label>
            <Select value={bookData.includeQuizzes} onValueChange={(value) => onUpdate({ includeQuizzes: value })}>
              <SelectTrigger id="includeQuizzes" className="w-full">
                <SelectValue placeholder="Select option" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="no">No quizzes</SelectItem>
                <SelectItem value="basic">Basic quizzes (1 per chapter)</SelectItem>
                <SelectItem value="comprehensive">Comprehensive quizzes (multiple per chapter)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">
              Quizzes help readers test their knowledge and improve engagement.
            </p>
          </div>
        </div>
      </div>

      <div className="p-6 bg-white">
        <h2 className="text-2xl font-bold mb-6">Graphic Template</h2>

        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="graphicTemplate">Choose a graphic template:</Label>
            <Select value={bookData.graphicTemplate} onValueChange={(value) => onUpdate({ graphicTemplate: value })}>
              <SelectTrigger id="graphicTemplate" className="w-full">
                <SelectValue placeholder="Select template" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No template (text only)</SelectItem>
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="academic">Academic</SelectItem>
                <SelectItem value="creative">Creative</SelectItem>
                <SelectItem value="minimal">Minimal</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">
              The graphic template will be applied when generating PDF and web versions of the book.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="colorScheme">Color scheme:</Label>
            <Select value={bookData.colorScheme} onValueChange={(value) => onUpdate({ colorScheme: value })}>
              <SelectTrigger id="colorScheme" className="w-full">
                <SelectValue placeholder="Select color scheme" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="blue">Blue</SelectItem>
                <SelectItem value="green">Green</SelectItem>
                <SelectItem value="purple">Purple</SelectItem>
                <SelectItem value="orange">Orange</SelectItem>
                <SelectItem value="gray">Gray</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="p-6 bg-white">
        <h2 className="text-2xl font-bold mb-6">Images (Optional)</h2>

        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="includeImages">Include images in your ebook?</Label>
            <Select value={bookData.includeImages} onValueChange={(value) => onUpdate({ includeImages: value })}>
              <SelectTrigger id="includeImages" className="w-full">
                <SelectValue placeholder="Select option" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No images</SelectItem>
                <SelectItem value="photos">Realistic photos</SelectItem>
                <SelectItem value="illustrations">Drawings/Illustrations</SelectItem>
                <SelectItem value="diagrams">Diagrams</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">Images will consume credits from your account.</p>
          </div>

          {bookData.includeImages && bookData.includeImages !== "none" && (
            <div className="space-y-2 mt-4">
              <Label htmlFor="imageCount">
                Number of images: <span className="font-medium ml-2">{bookData.imageCount || 10}</span>
              </Label>
              <Slider
                id="imageCount"
                min={5}
                max={50}
                step={5}
                value={[bookData.imageCount || 10]}
                onValueChange={(values) => onUpdate({ imageCount: values[0] })}
                className="w-full"
              />
              <p className="text-sm text-muted-foreground">Selecting more images will use more image credits.</p>
            </div>
          )}
        </div>
      </div>

      <WizardButtons onNext={onNext} onBack={onBack} />
    </div>
  )
}

export default BookFormatStep

