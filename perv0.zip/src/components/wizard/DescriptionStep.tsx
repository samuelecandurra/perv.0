"use client"
import { Textarea } from "@/components/ui/textarea"
import { Sparkles } from "lucide-react"
import WizardButtons from "./WizardButtons"

interface DescriptionStepProps {
  onUpdate: (
    data: Partial<{
      description: string
      uniqueSellingPoint: string
    }>,
  ) => void
  onNext: () => void
  onBack: () => void
  bookData: {
    description: string
    uniqueSellingPoint: string
    title: string
    niche: string
  }
}

const DescriptionStep = ({ onUpdate, onNext, onBack, bookData }: DescriptionStepProps) => {
  const isNextDisabled = !bookData.description

  const handleGenerateBrief = () => {
    // Here you would add logic to generate a description based on title and niche
    console.log("Generating brief based on:", bookData.title, bookData.niche)
    // For now, let's just set a placeholder
    if (bookData.title && bookData.niche) {
      onUpdate({
        description: `This is an AI-generated description for a ${bookData.niche} book titled "${bookData.title}". Replace this with your actual content.`,
      })
    }
  }

  return (
    <div className="space-y-8 font-['Canela',_'Playfair_Display',_Georgia,_serif]">
      <div className="text-center space-y-2 max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900">Book Description/Brief</h1>
        <p className="text-gray-600">This description will be used to generate your book structure and content.</p>
      </div>

      <div className="max-w-3xl mx-auto">
        <div className="relative border border-gray-100 rounded-lg bg-white p-6 shadow-sm">
          {/* Blue vertical accent bar */}
          <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#0EA5E9] rounded-l-lg"></div>

          <div className="pl-4 space-y-6">
            <h2 className="text-xl font-semibold text-gray-900">Description:</h2>
            <Textarea
              id="description"
              placeholder="Write a detailed description of your book..."
              value={bookData.description}
              onChange={(e) => onUpdate({ description: e.target.value })}
              className="min-h-[160px] resize-y bg-white border-gray-200 focus:border-[#0EA5E9] focus:ring-[#0EA5E9]"
            />
            <p className="text-sm text-gray-500 mt-2">
              You can write your own brief or let AI generate one based on your title and niche.
            </p>

            <button
              onClick={handleGenerateBrief}
              className="flex items-center mt-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 border border-gray-200 rounded-md"
            >
              <Sparkles className="h-4 w-4 mr-2 text-[#0EA5E9]" />
              Generate Brief
            </button>
          </div>
        </div>
      </div>

      <WizardButtons
        onNext={onNext}
        onBack={onBack}
        nextLabel="Avanti"
        backLabel="Indietro"
        isNextDisabled={isNextDisabled}
      />
    </div>
  )
}

export default DescriptionStep

