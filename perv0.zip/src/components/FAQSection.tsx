"use client"

import { useEffect } from "react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqs = [
  {
    question: "Serve esperienza tecnica?",
    answer:
      "Assolutamente no. Seribook è progettato per essere intuitivo e facile da usare anche per chi non ha competenze tecniche. L'interfaccia ti guida passo dopo passo, dalla scrittura alla pubblicazione finale.",
  },
  {
    question: "Posso creare sia ebook che cartacei?",
    answer:
      "Sì, Seribook ti permette di creare entrambi i formati. Puoi generare file EPUB e MOBI per gli ebook e PDF ad alta risoluzione per la stampa cartacea, tutti ottimizzati per le principali piattaforme di pubblicazione.",
  },
  {
    question: "È compatibile con Amazon KDP?",
    answer:
      "Certamente! I file generati da Seribook sono completamente compatibili con Amazon KDP, Kobo, Apple Books e tutte le principali piattaforme di self-publishing. Abbiamo progettato il sistema per garantire che i tuoi file passino i controlli di qualità di queste piattaforme al primo tentativo.",
  },
  {
    question: "Posso aggiornare il libro ogni anno?",
    answer:
      "Sì, questa è una delle caratteristiche più apprezzate di Seribook. Puoi modificare e aggiornare i tuoi libri in qualsiasi momento e riesportarli in pochi minuti. Questo è particolarmente utile per contenuti che necessitano di aggiornamenti periodici.",
  },
  {
    question: "Posso usarlo per lead magnet?",
    answer:
      "Assolutamente sì! Molti dei nostri utenti creano lead magnet professionali con Seribook. I template predefiniti ti permettono di creare guide, e-book e report dal look professionale, perfetti per attrarre e raccogliere contatti di potenziali clienti.",
  },
  {
    question: "Come funziona l'editor intelligente?",
    answer:
      "L'editor intelligente di Seribook analizza il testo in tempo reale, suggerendo correzioni grammaticali, miglioramenti stilistici e ottimizzazioni per la leggibilità. Utilizza algoritmi di AI avanzati per garantire che il tuo contenuto sia chiaro, coinvolgente e privo di errori.",
  },
]

const FAQSection = () => {
  useEffect(() => {
    // Add scroll animation to elements
    const observerOptions = {
      threshold: 0.1,
      rootMargin: "0px 0px -50px 0px",
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("shown")
        }
      })
    }, observerOptions)

    document.querySelectorAll(".appear-animation").forEach((el) => {
      observer.observe(el)
    })

    return () => observer.disconnect()
  }, [])

  return (
    <section id="faq" className="page-section bg-[#FFF7EF] relative overflow-hidden">
      {/* Background effect */}
      <div className="absolute inset-0 opacity-40 -z-10">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_20%,rgba(255,204,0,0.05)_0%,rgba(255,255,255,0)_80%)]"></div>
        <div className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(circle_at_70%_80%,rgba(255,204,0,0.05)_0%,rgba(255,255,255,0)_80%)]"></div>
      </div>

      <div className="max-w-4xl mx-auto appear-animation">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-semibold mb-4">Hai dubbi? Ecco le risposte</h2>
          <p className="text-xl text-gray-600">Rispondiamo alle domande più frequenti sul nostro servizio.</p>
        </div>

        <Accordion type="single" collapsible className="bg-white rounded-2xl shadow-md overflow-hidden">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`} className="border-b border-gray-200 last:border-b-0">
              <AccordionTrigger className="py-5 px-6 text-left text-lg font-medium hover:text-yellow-500 hover:no-underline">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="px-6 pb-5 pt-0 text-gray-600">{faq.answer}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="mt-10 text-center">
          <p className="text-gray-600">
            Non hai trovato la risposta che cercavi?{" "}
            <a href="#" className="text-yellow-500 hover:text-yellow-600 font-medium">
              Contattaci
            </a>
          </p>
        </div>
      </div>
    </section>
  )
}

export default FAQSection

