import { Button } from "@/components/ui/button"
import { Link } from "react-router-dom"
import { ArrowDown } from "lucide-react"

const HeroSection = () => {
  return (
    <section className="relative pt-32 pb-24 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-cream to-orange-soft -z-10"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="mb-6">
              <div className="inline-block px-4 py-1 rounded-full bg-orange-soft text-deep-black text-sm font-medium">
                Seribook — Per self-publisher che trattano i libri come un business
              </div>
            </div>

            <h1 className="font-heading font-bold text-5xl md:text-6xl lg:text-7xl leading-[1.2] mb-6 text-deep-black -tracking-[0.5px]">
              Crea il tuo libro in 5 minuti.
            </h1>

            <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl font-semibold text-orange mb-8 leading-[1.2] -tracking-[0.5px]">
              Pronto per Amazon KDP, Kobo, Apple Books e tutte le piattaforme digitali.
            </h2>

            <p className="font-body text-xl text-deep-black/80 mb-8 leading-[1.6]">
              Consegna in 5 minuti. Qualità da editore.
              <br />
              Senza nessun blocco. Nessuna complicazione.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Link to="/create-book">
                <Button
                  size="lg"
                  className="bg-[#FF5500] hover:bg-[#FF5500]/90 text-white rounded-full text-base font-semibold px-8 py-6 shadow-md hover:shadow-lg transition-all pulse-animation"
                >
                  🚀 Crea il tuo libro
                </Button>
              </Link>

              <Button
                variant="outline"
                size="lg"
                className="rounded-full border-2 border-[#FF5500]/20 text-[#FF5500] font-semibold hover:border-[#FF5500] hover:bg-[#FF5500]/10 px-8 py-6 text-base transition-all"
              >
                Scopri come funziona
              </Button>
            </div>
          </div>

          <div className="relative">
            {/* Book preview image */}
            <div className="bg-white rounded-2xl shadow-2xl p-6">
              <div className="aspect-video bg-muted-gray rounded-lg overflow-hidden">
                <img
                  src="/lovable-uploads/2fda1af4-8f02-41f4-bbac-0304c68678d3.png"
                  alt="Seribook preview"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.src = "https://placehold.co/600x400"
                  }}
                />
              </div>

              <div className="mt-6">
                <div className="flex gap-4 items-center">
                  <div className="w-1/3">
                    <div className="aspect-[3/4] bg-muted-gray rounded-lg overflow-hidden">
                      <img
                        src="https://placehold.co/300x400"
                        alt="Book mockup"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                  <div className="w-2/3 space-y-2">
                    <div className="h-3 bg-muted-gray rounded-full w-3/4"></div>
                    <div className="h-3 bg-muted-gray rounded-full w-1/2"></div>
                    <div className="h-3 bg-muted-gray rounded-full w-5/6"></div>
                    <div className="h-3 bg-muted-gray rounded-full w-2/3"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 animate-bounce">
        <a href="#problem" className="flex flex-col items-center text-orange hover:text-orange/80 transition-colors">
          <span className="text-sm font-medium mb-1">Scopri di più</span>
          <ArrowDown className="h-5 w-5" />
        </a>
      </div>
    </section>
  )
}

export default HeroSection

