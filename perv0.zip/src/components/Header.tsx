"use client"

import { useState, useEffect, useContext } from "react"
import { Button } from "@/components/ui/button"
import Link from "@/components/ui/Link"
import { NavigationContext } from "@/App"
import { cn } from "@/lib/utils"

const Header = () => {
  const { navigate } = useContext(NavigationContext)
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  // Check if user is authenticated
  const isAuthenticated = () => {
    return localStorage.getItem("userAuthenticated") === "true"
  }

  const handleStartNow = () => {
    if (isAuthenticated()) {
      navigate("/dashboard")
    } else {
      navigate("/auth", { returnTo: "/dashboard", action: null })
    }
  }

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-4",
        isScrolled ? "bg-background/80 backdrop-blur-md shadow-sm" : "bg-transparent",
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <img
                src="/lovable-uploads/ac709032-b968-4d6c-b151-99aa574cad77.png"
                alt="Seribook Logo"
                className="h-10 md:h-12"
              />
            </Link>
            <span className="hidden md:inline-block ml-2 text-sm text-muted-foreground">
              — Per self-publisher che trattano i libri come un business
            </span>
          </div>

          {/* Desktop navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#problem" className="text-sm font-medium text-foreground hover:text-orange transition-colors">
              Il problema
            </a>
            <a href="#solution" className="text-sm font-medium text-foreground hover:text-orange transition-colors">
              La soluzione
            </a>
            <a href="#testimonials" className="text-sm font-medium text-foreground hover:text-orange transition-colors">
              Testimonianze
            </a>
            <a href="#pricing" className="text-sm font-medium text-foreground hover:text-orange transition-colors">
              Prezzi
            </a>
            <a href="#faq" className="text-sm font-medium text-foreground hover:text-orange transition-colors">
              FAQ
            </a>
            {isAuthenticated() ? (
              <Button
                size="sm"
                className="bg-orange hover:bg-orange-light text-white rounded-full hover-lift font-semibold"
                onClick={() => navigate("/dashboard")}
              >
                Il mio account
              </Button>
            ) : (
              <Button
                size="sm"
                className="bg-orange hover:bg-orange-light text-white rounded-full hover-lift font-semibold pulse-animation"
                onClick={handleStartNow}
              >
                Inizia ora
              </Button>
            )}
          </nav>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="text-foreground focus:outline-none">
              {mobileMenuOpen ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
                </svg>
              )}
            </button>
          </div>
        </div>

        {/* Mobile navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 animate-fade-in">
            <div className="flex flex-col space-y-3">
              <a
                href="#problem"
                className="text-foreground hover:text-orange transition-colors py-2 font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Il problema
              </a>
              <a
                href="#solution"
                className="text-foreground hover:text-orange transition-colors py-2 font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                La soluzione
              </a>
              <a
                href="#testimonials"
                className="text-foreground hover:text-orange transition-colors py-2 font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Testimonianze
              </a>
              <a
                href="#pricing"
                className="text-foreground hover:text-orange transition-colors py-2 font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Prezzi
              </a>
              <a
                href="#faq"
                className="text-foreground hover:text-orange transition-colors py-2 font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                FAQ
              </a>
              {isAuthenticated() ? (
                <Button
                  size="sm"
                  className="bg-orange hover:bg-orange-light text-white rounded-full w-full font-semibold"
                  onClick={() => {
                    navigate("/dashboard")
                    setMobileMenuOpen(false)
                  }}
                >
                  Il mio account
                </Button>
              ) : (
                <Button
                  size="sm"
                  className="bg-orange hover:bg-orange-light text-white rounded-full w-full font-semibold"
                  onClick={() => {
                    handleStartNow()
                    setMobileMenuOpen(false)
                  }}
                >
                  Inizia ora
                </Button>
              )}
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}

export default Header

