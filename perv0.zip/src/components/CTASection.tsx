import { Button } from "@/components/ui/button"
import { Link } from "react-router-dom"

const CTASection = () => {
  return (
    <section className="w-full bg-orange-soft py-16 md:py-24 px-4 sm:px-6 text-[#1A1A1A] relative overflow-hidden shadow-sm border-t border-b border-[#EDEDED]">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden opacity-10">
        <div className="absolute -top-40 -left-40 w-80 h-80 rounded-full border-[30px] border-orange/20"></div>
        <div className="absolute -bottom-20 -right-20 w-60 h-60 rounded-full border-[20px] border-orange/20"></div>
        <div className="absolute top-1/4 right-1/4 w-40 h-40 rounded-full border-[15px] border-orange/20"></div>
      </div>

      <div className="max-w-4xl mx-auto text-center relative z-10">
        <h2 className="text-3xl md:text-4xl font-heading font-semibold mb-6">
          Il tuo prossimo libro può essere pronto oggi stesso.
        </h2>
        <p className="text-xl text-[#1A1A1A]/80 mb-10 leading-[1.6]">
          Pubblica senza stress, in pochi minuti. Seribook fa il lavoro al posto tuo.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/auth">
            <Button
              size="lg"
              className="bg-orange hover:bg-orange/90 text-white text-lg font-semibold rounded-full px-12 py-6 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1"
            >
              Inizia Gratis Ora
            </Button>
          </Link>

          <Link to="/auth">
            <Button
              variant="outline"
              size="lg"
              className="bg-transparent border-orange border-2 text-orange hover:bg-orange/5 text-lg font-semibold rounded-full px-12 py-6"
            >
              Scopri di più
            </Button>
          </Link>
        </div>

        <p className="mt-8 text-orange">Seribook — Per self-publisher che trattano i libri come un business.</p>
      </div>
    </section>
  )
}

export default CTASection

