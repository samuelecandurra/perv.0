"use client"

import { useEffect } from "react"
import { AlertTriangle, RefreshCw, Clock } from "lucide-react"

const ProblemSection = () => {
  useEffect(() => {
    // Add scroll animation to elements
    const observerOptions = {
      threshold: 0.1,
      rootMargin: "0px 0px -50px 0px",
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("shown")
        }
      })
    }, observerOptions)

    document.querySelectorAll(".appear-animation").forEach((el) => {
      observer.observe(el)
    })

    return () => observer.disconnect()
  }, [])

  return (
    <section id="problem" className="page-section relative overflow-hidden bg-orange-soft py-24">
      <div className="max-w-4xl mx-auto text-center mb-16 appear-animation">
        <h2 className="text-3xl md:text-4xl font-display font-semibold mb-4">Ti suona familiare?</h2>
        <p className="text-xl text-[#1A1A1A]/70">Questi sono i problemi che affrontano ogni giorno i self-publisher.</p>
      </div>

      <div className="max-w-5xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Problem 1 */}
          <div
            className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300 appear-animation"
            style={{ transitionDelay: "0.1s" }}
          >
            <div className="w-16 h-16 bg-orange-soft text-orange rounded-full flex items-center justify-center mb-6 mx-auto">
              <AlertTriangle className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-semibold mb-4 text-center">Bloccato su KDP dopo giorni di lavoro?</h3>
            <p className="text-[#1A1A1A]/70 text-center">
              Dopo ore di formattazione, Amazon rifiuta il tuo libro per piccoli errori tecnici che non riesci a
              individuare.
            </p>
          </div>

          {/* Problem 2 */}
          <div
            className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300 appear-animation"
            style={{ transitionDelay: "0.2s" }}
          >
            <div className="w-16 h-16 bg-orange-soft text-orange rounded-full flex items-center justify-center mb-6 mx-auto">
              <RefreshCw className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-semibold mb-4 text-center">Google Docs + ChatGPT + Word = caos?</h3>
            <p className="text-[#1A1A1A]/70 text-center">
              Passare da uno strumento all'altro fa perdere tempo, causa errori e crea file incompatibili con le
              piattaforme di pubblicazione.
            </p>
          </div>

          {/* Problem 3 */}
          <div
            className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300 appear-animation"
            style={{ transitionDelay: "0.3s" }}
          >
            <div className="w-16 h-16 bg-orange-soft text-orange rounded-full flex items-center justify-center mb-6 mx-auto">
              <Clock className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-semibold mb-4 text-center">
              Tempi lunghi con freelancer e risultati mediocri?
            </h3>
            <p className="text-[#1A1A1A]/70 text-center">
              Aspettare settimane per ricevere un lavoro che poi richiede comunque delle correzioni è frustrante e
              costoso.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

export default ProblemSection

