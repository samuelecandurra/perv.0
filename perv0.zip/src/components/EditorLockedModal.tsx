"use client"
import { useContext } from "react"
import { NavigationContext } from "@/App"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

interface EditorLockedModalProps {
  isOpen: boolean
  onClose: () => void
  projectTitle: string
  projectId: number
}

const EditorLockedModal = ({ isOpen, onClose, projectTitle, projectId }: EditorLockedModalProps) => {
  const { navigate } = useContext(NavigationContext)

  const handleBuyBook = () => {
    // In a real app, this would redirect to a payment page for this specific book
    navigate(`/checkout/${projectId}`)
    onClose()
  }

  const handleViewPlans = () => {
    // Redirect to the pricing page
    navigate("/pricing")
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl">Editor bloccato per questo libro</DialogTitle>
          <DialogDescription className="text-gray-600 mt-2">
            Per accedere all'editor di "{projectTitle}", acquista il libro o attiva un piano PRO.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-3 mt-3">
          <Button onClick={handleBuyBook} className="bg-[#FF5500] hover:bg-[#FF5500]/90 text-white w-full">
            Acquista questo libro – €9.99
          </Button>

          <Button
            onClick={handleViewPlans}
            variant="secondary"
            className="w-full border border-[#FF5500] text-[#FF5500] hover:bg-[#FF5500]/10"
          >
            Scopri i piani PRO
          </Button>

          <Button onClick={onClose} variant="outline" className="w-full">
            Annulla
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default EditorLockedModal

