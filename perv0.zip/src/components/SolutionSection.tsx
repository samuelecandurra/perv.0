"use client"

import { useEffect } from "react"

const SolutionSection = () => {
  useEffect(() => {
    // Add scroll animation to elements
    const observerOptions = {
      threshold: 0.1,
      rootMargin: "0px 0px -50px 0px",
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("shown")
        }
      })
    }, observerOptions)

    document.querySelectorAll(".appear-animation").forEach((el) => {
      observer.observe(el)
    })

    return () => observer.disconnect()
  }, [])

  return (
    <section id="solution" className="page-section relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-white to-blue-50 -z-10"></div>

      <div className="max-w-4xl mx-auto text-center mb-16 appear-animation">
        <span className="inline-block px-3 py-1 rounded-full bg-green-100 text-green-800 text-sm font-medium mb-4">
          LA SOLUZIONE: SERIBOOK
        </span>
        <h2 className="text-3xl md:text-4xl font-display font-semibold mb-4">
          Tutto ciò che ti serve, in un'unica piattaforma.
        </h2>
        <p className="text-xl text-gray-600">
          Abbiamo creato uno strumento completo che risolve tutti i problemi dei self-publisher.
        </p>
      </div>

      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
          {/* Feature 1 */}
          <div className="appear-animation" style={{ transitionDelay: "0.1s" }}>
            <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 h-full flex flex-col">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Scrivi o importa contenuti in un click</h3>
              <p className="text-gray-600 mb-4 flex-grow">
                Importa direttamente i tuoi testi da Word, Google Docs o scrivi direttamente nell'editor intuitivo.
              </p>
              <div className="mt-auto">
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <img
                    src="https://placehold.co/600x400"
                    alt="Editor interface"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Feature 2 */}
          <div className="appear-animation" style={{ transitionDelay: "0.2s" }}>
            <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 h-full flex flex-col">
              <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Editor intelligente con miglioramento automatico</h3>
              <p className="text-gray-600 mb-4 flex-grow">
                L'AI integrata verifica grammatica, stile e leggibilità, suggerendo miglioramenti in tempo reale.
              </p>
              <div className="mt-auto">
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <img
                    src="https://placehold.co/600x400"
                    alt="AI correction demo"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Feature 3 */}
          <div className="appear-animation" style={{ transitionDelay: "0.3s" }}>
            <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 h-full flex flex-col">
              <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Template grafici professionali già pronti</h3>
              <p className="text-gray-600 mb-4 flex-grow">
                Scegli tra decine di design curati da grafici professionisti per dare al tuo libro un aspetto
                professionale.
              </p>
              <div className="mt-auto">
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <img
                    src="https://placehold.co/600x400"
                    alt="Templates gallery"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Feature 4 */}
          <div className="appear-animation" style={{ transitionDelay: "0.4s" }}>
            <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 h-full flex flex-col">
              <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Protezione copyright e anti-plagio</h3>
              <p className="text-gray-600 mb-4 flex-grow">
                Sistema integrato per verificare l'originalità dei contenuti e proteggere la tua proprietà
                intellettuale.
              </p>
              <p className="text-gray-600 text-sm italic">
                Ogni libro è generato in modo originale e naturale, pronto per la pubblicazione e senza rischio di
                blocchi su Amazon KDP o altre piattaforme.
              </p>
              <div className="mt-auto">
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <img
                    src="https://placehold.co/600x400"
                    alt="Copyright protection"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Feature 5 */}
          <div className="appear-animation" style={{ transitionDelay: "0.5s" }}>
            <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 h-full flex flex-col">
              <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Esportazione per tutte le piattaforme</h3>
              <p className="text-gray-600 mb-4 flex-grow">
                Genera file EPUB, MOBI e PDF ottimizzati e conformi agli standard di Amazon KDP, Kobo, Apple Books e
                altre piattaforme.
              </p>
              <p className="text-gray-600 text-sm italic">
                Ogni libro è generato in modo originale e naturale, pronto per la pubblicazione e senza rischio di
                blocchi su Amazon KDP o altre piattaforme.
              </p>
              <div className="mt-auto">
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <img src="https://placehold.co/600x400" alt="Export formats" className="w-full h-full object-cover" />
                </div>
              </div>
            </div>
          </div>

          {/* Feature 6 */}
          <div className="appear-animation" style={{ transitionDelay: "0.6s" }}>
            <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 h-full flex flex-col">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Aggiornamento continuo del tuo libro</h3>
              <p className="text-gray-600 mb-4 flex-grow">
                Mantieni il tuo libro aggiornato e ripubblicalo con pochi clic ogni volta che desideri aggiungere
                contenuti o correzioni.
              </p>
              <div className="mt-auto">
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <img src="https://placehold.co/600x400" alt="Update process" className="w-full h-full object-cover" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default SolutionSection

