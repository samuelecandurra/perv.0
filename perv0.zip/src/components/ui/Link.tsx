"use client"

import type React from "react"
import { useContext } from "react"
import { NavigationContext, type NavigationState } from "../../App"

interface LinkProps {
  to: string
  children: React.ReactNode
  className?: string
  state?: NavigationState
  onClick?: (e: React.MouseEvent) => void
}

const Link: React.FC<LinkProps> = ({ to, children, className, state, onClick }) => {
  const { navigate } = useContext(NavigationContext)

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault()

    if (onClick) {
      onClick(e)
    }

    navigate(to, state)
  }

  return (
    <a href={to} className={className} onClick={handleClick}>
      {children}
    </a>
  )
}

export default Link

