import { Check, X, AlertTriangle, Star } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Table, TableHeader, TableBody, TableFooter, TableHead, TableRow, TableCell } from "@/components/ui/table"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

const ComparisonTable = () => {
  // Function to render appropriate icon for boolean or partial values
  const renderFeatureStatus = (value: boolean | "partial") => {
    if (value === true) {
      return (
        <div className="flex items-center justify-center">
          <Check className="h-4 w-4 text-green-600" />
        </div>
      )
    } else if (value === "partial") {
      return (
        <div className="flex items-center justify-center">
          <AlertTriangle className="h-4 w-4 text-amber-500" />
        </div>
      )
    } else {
      return (
        <div className="flex items-center justify-center">
          <X className="h-4 w-4 text-red-600" />
        </div>
      )
    }
  }

  // Function to render star rating
  const renderStarRating = (rating: number, maxRating = 5) => {
    return (
      <div className="flex items-center justify-center">
        {Array.from({ length: maxRating }).map((_, i) => (
          <Star
            key={i}
            size={14}
            className={cn(i < rating ? "fill-[#FF8A00] text-[#FF8A00]" : "text-gray-200 fill-gray-200")}
          />
        ))}
      </div>
    )
  }

  return (
    <div className="page-section py-12">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-center font-heading text-2xl md:text-3xl font-semibold mb-3">Platform Comparison</h2>
        <p className="text-center mb-8 text-muted-foreground max-w-lg mx-auto text-sm">
          See how Seribook compares to other book creation platforms
        </p>

        <div className="relative overflow-hidden rounded-xl border shadow-md">
          <ScrollArea className="w-full overflow-auto">
            <Table className="min-w-[600px]">
              <TableHeader>
                <TableRow className="bg-[#FFF5EB]">
                  <TableHead className="sticky left-0 bg-[#FFF5EB] z-10 font-semibold w-[180px]">Features</TableHead>

                  <TableHead className="relative text-center font-semibold px-4 py-3 border-x-2 border-[#FF8A00]/30 bg-[#FFF5EB]">
                    <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
                      <Badge variant="default" className="bg-[#FF8A00] hover:bg-[#FF7A00] px-2 py-0.5 text-xs mt-1">
                        Recommended
                      </Badge>
                    </div>
                    <div className="text-base font-bold text-[#FF8A00] mt-2">Seribook</div>
                  </TableHead>

                  <TableHead className="text-center font-medium px-4 text-sm">Competitors</TableHead>
                </TableRow>
              </TableHeader>

              <TableBody>
                {/* Pricing Section */}
                <TableRow className="bg-gray-50">
                  <TableCell colSpan={3} className="sticky left-0 font-bold text-sm py-2 bg-gray-50">
                    Pricing
                  </TableCell>
                </TableRow>

                <TableRow className="hover:bg-[#FF8A00]/5 transition-colors">
                  <TableCell className="sticky left-0 bg-white font-medium text-sm">Starting Price</TableCell>
                  <TableCell className="text-center text-sm font-semibold border-x-2 border-[#FF8A00]/30 bg-[#FFF5EB]/30">
                    $19.99
                  </TableCell>
                  <TableCell className="text-center text-sm">$27-50/mo</TableCell>
                </TableRow>

                <TableRow className="hover:bg-[#FF8A00]/5 transition-colors">
                  <TableCell className="sticky left-0 bg-white font-medium text-sm">Real Cost per Book</TableCell>
                  <TableCell className="text-center text-sm font-semibold border-x-2 border-[#FF8A00]/30 bg-[#FFF5EB]/30">
                    $19.99
                  </TableCell>
                  <TableCell className="text-center text-sm">$100-1000+</TableCell>
                </TableRow>

                {/* Content Quality Section */}
                <TableRow className="bg-gray-50">
                  <TableCell colSpan={3} className="sticky left-0 font-bold text-sm py-2 bg-gray-50">
                    Content Quality
                  </TableCell>
                </TableRow>

                <TableRow className="hover:bg-[#FF8A00]/5 transition-colors">
                  <TableCell className="sticky left-0 bg-white font-medium text-sm">Preview Before Payment</TableCell>
                  <TableCell className="border-x-2 border-[#FF8A00]/30 bg-[#FFF5EB]/30">
                    {renderFeatureStatus(true)}
                  </TableCell>
                  <TableCell>{renderFeatureStatus(false)}</TableCell>
                </TableRow>

                <TableRow className="hover:bg-[#FF8A00]/5 transition-colors">
                  <TableCell className="sticky left-0 bg-white font-medium text-sm">Plagiarism-Free</TableCell>
                  <TableCell className="border-x-2 border-[#FF8A00]/30 bg-[#FFF5EB]/30">
                    {renderFeatureStatus(true)}
                  </TableCell>
                  <TableCell>{renderFeatureStatus("partial")}</TableCell>
                </TableRow>

                {/* Compatibility Section */}
                <TableRow className="bg-gray-50">
                  <TableCell colSpan={3} className="sticky left-0 font-bold text-sm py-2 bg-gray-50">
                    Compatibility
                  </TableCell>
                </TableRow>

                <TableRow className="hover:bg-[#FF8A00]/5 transition-colors">
                  <TableCell className="sticky left-0 bg-white font-medium text-sm">Amazon KDP Compatibility</TableCell>
                  <TableCell className="border-x-2 border-[#FF8A00]/30 bg-[#FFF5EB]/30">
                    {renderFeatureStatus(true)}
                  </TableCell>
                  <TableCell>{renderFeatureStatus("partial")}</TableCell>
                </TableRow>

                {/* User Experience Section */}
                <TableRow className="bg-gray-50">
                  <TableCell colSpan={3} className="sticky left-0 font-bold text-sm py-2 bg-gray-50">
                    User Experience
                  </TableCell>
                </TableRow>

                <TableRow className="hover:bg-[#FF8A00]/5 transition-colors">
                  <TableCell className="sticky left-0 bg-white font-medium text-sm">Ease of Use</TableCell>
                  <TableCell className="border-x-2 border-[#FF8A00]/30 bg-[#FFF5EB]/30">
                    {renderStarRating(5)}
                  </TableCell>
                  <TableCell>{renderStarRating(3)}</TableCell>
                </TableRow>

                <TableRow className="hover:bg-[#FF8A00]/5 transition-colors">
                  <TableCell className="sticky left-0 bg-white font-medium text-sm">Book Creation Time</TableCell>
                  <TableCell className="text-center font-semibold text-sm border-x-2 border-[#FF8A00]/30 bg-[#FFF5EB]/30">
                    5 minutes
                  </TableCell>
                  <TableCell className="text-center text-sm">Hours to weeks</TableCell>
                </TableRow>
              </TableBody>

              <TableFooter>
                <TableRow>
                  <TableCell className="sticky left-0 bg-[#FFF5EB] font-medium text-sm">Overall Value</TableCell>
                  <TableCell className="text-center font-bold text-[#FF8A00] text-sm border-x-2 border-[#FF8A00]/30 bg-[#FFF5EB]/50">
                    Excellent
                  </TableCell>
                  <TableCell className="text-center text-sm">Variable</TableCell>
                </TableRow>
              </TableFooter>
            </Table>
          </ScrollArea>
        </div>

        <div className="mt-4 text-xs text-muted-foreground text-center">
          <p>* Prices and features current as of 2023. Subject to change based on provider's offerings.</p>
        </div>
      </div>
    </div>
  )
}

export default ComparisonTable

