"use client"

import type React from "react"
import { Check, PencilLine } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Chapter {
  id: number
  title: string
  status: string
  content: string
}

interface ChaptersSidebarProps {
  chapters: Chapter[]
  activeChapter: number
  remainingWords: number
  bookWordCount?: string | number
  onChapterClick: (index: number) => void
}

const ChaptersSidebar: React.FC<ChaptersSidebarProps> = ({
  chapters,
  activeChapter,
  remainingWords,
  bookWordCount,
  onChapterClick,
}) => {
  return (
    <div className="w-64 flex-shrink-0 overflow-y-auto border-r border-gray-200 bg-white h-full">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <h2 className="text-base font-medium">Capitoli del libro</h2>
        <Button
          variant="ghost"
          size="sm"
          className="p-1 h-auto text-[#FF5500] hover:text-[#FF5500]/80 hover:bg-[#FF5500]/10"
        >
          <PencilLine className="h-4 w-4" />
        </Button>
      </div>

      {/* Word Count Remaining Display */}
      <div className="px-4 py-3 bg-[#FFF5EB] border-b border-[#FFDAB5]">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-[#FF5500]">Parole rimanenti:</span>
          <span
            className={`text-sm font-bold ${remainingWords > 1000 ? "text-green-600" : remainingWords > 300 ? "text-amber-600" : "text-red-600"}`}
          >
            {remainingWords.toLocaleString("it-IT")}
          </span>
        </div>
        <div className="mt-1 h-1.5 w-full bg-gray-200 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full ${remainingWords > 1000 ? "bg-green-500" : remainingWords > 300 ? "bg-amber-500" : "bg-red-500"}`}
            style={{
              width: `${Math.min(100, 100 - (remainingWords / (Number.parseInt(bookWordCount?.toString() || "10000", 10) || 10000)) * 100)}%`,
            }}
          ></div>
        </div>
      </div>

      {/* Chapter List */}
      <div className="py-2">
        {chapters.map((chapter, index) => (
          <div
            key={chapter.id}
            onClick={() => onChapterClick(index)}
            className={`flex items-center px-4 py-3 cursor-pointer hover:bg-[#FFF5EB] transition-colors ${activeChapter === index ? "border-l-4 border-[#FF5500] bg-[#FFF5EB]" : ""}`}
          >
            <div className="mr-3">
              {chapter.status === "completed" ? (
                <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center">
                  <Check className="h-3 w-3 text-green-600" />
                </div>
              ) : chapter.status === "editing" ? (
                <div className="w-5 h-5 rounded-full bg-[#FFF5EB] flex items-center justify-center">
                  <PencilLine className="h-3 w-3 text-[#FF5500]" />
                </div>
              ) : (
                <div className="w-5 h-5 rounded-full bg-gray-200" />
              )}
            </div>
            <span className="text-sm text-gray-700">{chapter.title}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export default ChaptersSidebar

