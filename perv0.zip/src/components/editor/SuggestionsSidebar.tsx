"use client"

import type React from "react"
import { Check, Sparkles, GanttChart, Lightbulb, History, Clock, BookOpen } from "lucide-react"
import { Separator } from "@/components/ui/separator"

interface SuggestionsSidebarProps {
  onApplySuggestion: (suggestionType: string) => void
}

const SuggestionsSidebar: React.FC<SuggestionsSidebarProps> = ({ onApplySuggestion }) => {
  return (
    <div className="w-72 flex-shrink-0 overflow-y-auto border-l border-gray-200 bg-white h-full">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-base font-medium">Migliora il tuo testo</h2>
      </div>

      <div className="p-4 space-y-3">
        <div
          onClick={() => onApplySuggestion("Migliora la grammatica")}
          className="flex items-center p-3 hover:bg-[#FFF5EB] rounded-md cursor-pointer transition-colors"
        >
          <div className="w-8 h-8 rounded-full bg-green-50 flex items-center justify-center mr-3">
            <Check className="h-4 w-4 text-green-600" />
          </div>
          <span className="text-sm">Migliora la grammatica</span>
        </div>

        <div
          onClick={() => onApplySuggestion("Riscrivi con più fluidità")}
          className="flex items-center p-3 hover:bg-[#FFF5EB] rounded-md cursor-pointer transition-colors"
        >
          <div className="w-8 h-8 rounded-full bg-[#FFF5EB] flex items-center justify-center mr-3">
            <Sparkles className="h-4 w-4 text-[#FF5500]" />
          </div>
          <span className="text-sm">Riscrivi con più fluidità</span>
        </div>

        <div
          onClick={() => onApplySuggestion("Rendi più chiaro il messaggio")}
          className="flex items-center p-3 hover:bg-[#FFF5EB] rounded-md cursor-pointer transition-colors"
        >
          <div className="w-8 h-8 rounded-full bg-amber-50 flex items-center justify-center mr-3">
            <GanttChart className="h-4 w-4 text-amber-600" />
          </div>
          <span className="text-sm">Rendi più chiaro il messaggio</span>
        </div>

        <div
          onClick={() => onApplySuggestion("Aggiungi tono più coinvolgente")}
          className="flex items-center p-3 hover:bg-[#FFF5EB] rounded-md cursor-pointer transition-colors"
        >
          <div className="w-8 h-8 rounded-full bg-purple-50 flex items-center justify-center mr-3">
            <Lightbulb className="h-4 w-4 text-purple-600" />
          </div>
          <span className="text-sm">Aggiungi tono più coinvolgente</span>
        </div>

        <Separator className="my-4" />

        <div className="p-4 bg-[#FFF5EB] rounded-lg border border-[#FFDAB5] mt-2">
          <h3 className="text-xs font-medium mb-2 text-[#FF5500] flex items-center">
            <Sparkles className="h-3 w-3 mr-1 text-[#FF5500]" />
            Suggerimento AI
          </h3>
          <p className="text-xs text-[#FF5500]/80">
            Prova a includere più esempi pratici in questo capitolo per migliorare la comprensione del lettore.
          </p>
        </div>

        <div className="mt-6">
          <h3 className="text-xs font-medium mb-3 flex items-center">
            <History className="h-3 w-3 mr-1" />
            Cronologia modifiche
          </h3>
          <div className="text-xs text-gray-500 space-y-2">
            <div className="flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              <span>Ultima modifica: 10 minuti fa</span>
            </div>
            <div className="flex items-center">
              <BookOpen className="h-3 w-3 mr-1" />
              <span>Versione: 1.2</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SuggestionsSidebar

