"use client"

import type React from "react"
import { useContext } from "react"
import { NavigationContext } from "@/App"
import { ChevronLeft, FileText, Import, Eye, FileOutput, FileIcon, BookOpen, BookCopy, FileType } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface EditorHeaderProps {
  wordCount: number
  handleExport: (format: string) => void
  handleSave: () => void
}

const EditorHeader: React.FC<EditorHeaderProps> = ({ wordCount, handleExport, handleSave }) => {
  const { navigate } = useContext(NavigationContext)

  return (
    <div className="bg-white border-b flex items-center p-2 px-4 shadow-sm sticky top-0 z-10">
      <Button variant="ghost" size="sm" className="mr-2 hover:text-[#FF5500]" onClick={() => navigate("/dashboard")}>
        <ChevronLeft className="h-4 w-4 mr-1" />
        Dashboard
      </Button>
      <Separator orientation="vertical" className="h-6 mx-2" />

      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" className="flex items-center gap-1 hover:text-[#FF5500]">
          <FileText className="h-4 w-4" />
          Scrivi
        </Button>
        <Button variant="ghost" size="sm" className="flex items-center gap-1 hover:text-[#FF5500]">
          <Import className="h-4 w-4" />
          Importa
        </Button>
        <Button variant="ghost" size="sm" className="flex items-center gap-1 hover:text-[#FF5500]">
          <Eye className="h-4 w-4" />
          Anteprima
        </Button>

        {/* Export Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="flex items-center gap-1 hover:text-[#FF5500]">
              <FileOutput className="h-4 w-4" />
              Esporta
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-48 bg-white shadow-md">
            <DropdownMenuItem onClick={() => handleExport("PDF")} className="flex items-center hover:bg-[#FF5500]/10">
              <FileIcon className="h-4 w-4 mr-2 text-red-500" />
              <span>PDF</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleExport("EPUB")} className="flex items-center hover:bg-[#FF5500]/10">
              <BookOpen className="h-4 w-4 mr-2 text-blue-500" />
              <span>EPUB</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleExport("MOBI")} className="flex items-center hover:bg-[#FF5500]/10">
              <BookCopy className="h-4 w-4 mr-2 text-green-500" />
              <span>MOBI (Kindle)</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleExport("DOCX")} className="flex items-center hover:bg-[#FF5500]/10">
              <FileType className="h-4 w-4 mr-2 text-indigo-500" />
              <span>Word (DOCX)</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleExport("TXT")} className="flex items-center hover:bg-[#FF5500]/10">
              <FileText className="h-4 w-4 mr-2 text-gray-500" />
              <span>Testo (TXT)</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="ml-auto flex items-center gap-4">
        <span className="text-sm text-gray-500">Parole: {wordCount}</span>
        <Button
          variant="default"
          size="sm"
          onClick={handleSave}
          className="flex items-center gap-1 bg-[#FF5500] hover:bg-[#FF5500]/90 text-white"
        >
          Salvato
        </Button>
      </div>
    </div>
  )
}

export default EditorHeader

