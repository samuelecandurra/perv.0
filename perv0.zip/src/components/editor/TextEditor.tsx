"use client"

import type React from "react"
import {
  Bold,
  Italic,
  List,
  ListOrdered,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Heading1,
  Heading2,
  Heading3,
  RotateCcw,
  Eye,
  Clock,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

interface TextEditorProps {
  chapterTitle: string
  chapterContent: string
  onTitleChange: (title: string) => void
  onContentChange: (content: string) => void
  onResetToAIVersion: () => void
  onPreviewClick: () => void
}

const TextEditor: React.FC<TextEditorProps> = ({
  chapterTitle,
  chapterContent,
  onTitleChange,
  onContentChange,
  onResetToAIVersion,
  onPreviewClick,
}) => {
  const formatText = (type: string) => {
    console.log(`Formatting text as ${type}`)
  }

  return (
    <div className="max-w-4xl mx-auto w-full bg-white rounded-lg shadow-sm my-6 flex flex-col">
      {/* Editor header with title input */}
      <div className="p-4 border-b border-gray-200">
        <input
          type="text"
          value={chapterTitle}
          onChange={(e) => onTitleChange(e.target.value)}
          className="w-full text-2xl font-serif font-medium border-none outline-none focus:ring-2 focus:ring-[#FF5500]/20"
          placeholder="Titolo del capitolo"
        />
      </div>

      {/* Formatting toolbar */}
      <div className="flex flex-wrap items-center p-2 gap-1 border-b border-gray-200 bg-gray-50">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => formatText("h1")}
          className="p-1 h-8 w-8 hover:text-[#FF5500] hover:bg-[#FF5500]/10"
        >
          <Heading1 className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => formatText("h2")}
          className="p-1 h-8 w-8 hover:text-[#FF5500] hover:bg-[#FF5500]/10"
        >
          <Heading2 className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => formatText("h3")}
          className="p-1 h-8 w-8 hover:text-[#FF5500] hover:bg-[#FF5500]/10"
        >
          <Heading3 className="h-4 w-4" />
        </Button>

        <div className="w-px h-6 bg-gray-300 mx-1"></div>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => formatText("bold")}
          className="p-1 h-8 w-8 hover:text-[#FF5500] hover:bg-[#FF5500]/10"
        >
          <Bold className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => formatText("italic")}
          className="p-1 h-8 w-8 hover:text-[#FF5500] hover:bg-[#FF5500]/10"
        >
          <Italic className="h-4 w-4" />
        </Button>

        <div className="w-px h-6 bg-gray-300 mx-1"></div>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => formatText("list")}
          className="p-1 h-8 w-8 hover:text-[#FF5500] hover:bg-[#FF5500]/10"
        >
          <List className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => formatText("ordered-list")}
          className="p-1 h-8 w-8 hover:text-[#FF5500] hover:bg-[#FF5500]/10"
        >
          <ListOrdered className="h-4 w-4" />
        </Button>

        <div className="w-px h-6 bg-gray-300 mx-1"></div>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => formatText("align-left")}
          className="p-1 h-8 w-8 hover:text-[#FF5500] hover:bg-[#FF5500]/10"
        >
          <AlignLeft className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => formatText("align-center")}
          className="p-1 h-8 w-8 hover:text-[#FF5500] hover:bg-[#FF5500]/10"
        >
          <AlignCenter className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => formatText("align-right")}
          className="p-1 h-8 w-8 hover:text-[#FF5500] hover:bg-[#FF5500]/10"
        >
          <AlignRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Content textarea */}
      <Textarea
        value={chapterContent}
        onChange={(e) => onContentChange(e.target.value)}
        className="flex-1 min-h-[500px] p-6 text-lg border-none rounded-none font-['Playfair_Display',_serif] focus-visible:ring-0 focus-visible:ring-offset-0"
        placeholder="Inizia a scrivere qui..."
      />

      {/* Editor footer */}
      <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200 bg-gray-50 text-xs text-gray-500">
        <div className="flex items-center">
          <Clock className="h-3 w-3 mr-1" />
          <span>Ultimo salvataggio: 2 minuti fa</span>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={onResetToAIVersion}
            className="text-xs h-7 hover:text-[#FF5500] hover:bg-[#FF5500]/10"
          >
            <RotateCcw className="h-3 w-3 mr-1" />
            Ripristina
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onPreviewClick}
            className="text-xs h-7 hover:text-[#FF5500] hover:bg-[#FF5500]/10"
          >
            <Eye className="h-3 w-3 mr-1" />
            Anteprima
          </Button>
        </div>
      </div>
    </div>
  )
}

export default TextEditor

